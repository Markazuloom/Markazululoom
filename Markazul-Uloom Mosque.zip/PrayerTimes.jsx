import React, { useState, useEffect } from 'react';

const PrayerTimes = () => {
  const [currentTime, setCurrentTime] = useState(new Date());
  const [nextPrayer, setNextPrayer] = useState('');

  // Prayer times for Alagbado, Lagos, Nigeria
  const prayerTimes = {
    fajr: { time: '05:13', arabic: 'الفجر', name: 'Fajr' },
    sunrise: { time: '06:31', arabic: 'الشروق', name: 'Sunrise' },
    dhuhr: { time: '12:47', arabic: 'الظهر', name: 'Dhuhr' },
    asr: { time: '16:15', arabic: 'العصر', name: 'Asr' },
    maghrib: { time: '19:04', arabic: 'المغرب', name: 'Maghrib' },
    isha: { time: '20:15', arabic: 'العشاء', name: 'Isha' }
  };

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    const findNextPrayer = () => {
      const now = new Date();
      const currentTimeStr = now.toTimeString().slice(0, 5);
      
      const prayers = ['fajr', 'dhuhr', 'asr', 'maghrib', 'isha'];
      
      for (let prayer of prayers) {
        if (currentTimeStr < prayerTimes[prayer].time) {
          setNextPrayer(prayer);
          return;
        }
      }
      setNextPrayer('fajr'); // Next day's Fajr
    };

    findNextPrayer();
  }, [currentTime]);

  const formatDate = (date) => {
    return date.toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const formatTime = (date) => {
    return date.toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    });
  };

  return (
    <div className="prayer-times-page">
      {/* Header Section */}
      <section className="section" style={{ background: 'linear-gradient(135deg, #1e3a8a 0%, #3b82f6 100%)', color: 'white' }}>
        <div className="container">
          <div style={{ textAlign: 'center' }}>
            <div className="bismillah arabic-text" style={{ color: '#ffd700', fontSize: '2rem' }}>
              بِسْمِ اللَّهِ الرَّحْمَنِ الرَّحِيم
            </div>
            <h1 style={{ fontSize: '3rem', margin: '2rem 0', color: 'white' }}>Prayer Times</h1>
            <p style={{ fontSize: '1.3rem', marginBottom: '1rem' }}>
              Accurate prayer times for Alagbado, Lagos, Nigeria
            </p>
            <div className="arabic-text" style={{ color: '#ffd700', fontSize: '1.2rem' }}>
              أَقِمِ الصَّلَاةَ لِدُلُوكِ الشَّمْسِ إِلَىٰ غَسَقِ اللَّيْلِ
            </div>
            <p style={{ fontStyle: 'italic', marginTop: '1rem' }}>
              "Establish prayer at the decline of the sun until the darkness of the night" - Quran 17:78
            </p>
          </div>
        </div>
      </section>

      {/* Current Time and Date */}
      <section className="section">
        <div className="container">
          <div className="card" style={{ textAlign: 'center', background: 'linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%)' }}>
            <h2 style={{ color: '#1e3a8a', marginBottom: '1rem' }}>Current Time</h2>
            <div style={{ fontSize: '2.5rem', fontWeight: 'bold', color: '#1e3a8a', marginBottom: '1rem' }}>
              {formatTime(currentTime)}
            </div>
            <div style={{ fontSize: '1.2rem', color: '#666', marginBottom: '1rem' }}>
              {formatDate(currentTime)}
            </div>
            {nextPrayer && (
              <div style={{ padding: '1rem', background: '#1e3a8a', color: 'white', borderRadius: '10px', display: 'inline-block' }}>
                <strong>Next Prayer: {prayerTimes[nextPrayer].name} at {prayerTimes[nextPrayer].time}</strong>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Prayer Times Grid */}
      <section className="section">
        <div className="container">
          <h2 className="section-title">Daily Prayer Schedule</h2>
          <div className="prayer-times-grid">
            {Object.entries(prayerTimes).map(([key, prayer]) => (
              <div 
                key={key} 
                className={`prayer-time-card ${nextPrayer === key ? 'next-prayer' : ''}`}
                style={nextPrayer === key ? { 
                  background: 'linear-gradient(135deg, #ffd700 0%, #ffed4e 100%)', 
                  color: '#1e3a8a',
                  transform: 'scale(1.05)'
                } : {}}
              >
                <h3 style={nextPrayer === key ? { color: '#1e3a8a' } : {}}>{prayer.name}</h3>
                <div className="time">{prayer.time}</div>
                <div className="arabic" style={nextPrayer === key ? { color: '#1e3a8a' } : {}}>{prayer.arabic}</div>
                {nextPrayer === key && (
                  <div style={{ marginTop: '0.5rem', fontSize: '0.9rem', fontWeight: 'bold' }}>
                    NEXT PRAYER
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Prayer Information */}
      <section className="section" style={{ backgroundColor: '#f8fafc' }}>
        <div className="container">
          <h2 className="section-title">Prayer Information</h2>
          <div className="grid grid-2">
            <div className="card">
              <h3>Location Details</h3>
              <ul style={{ paddingLeft: '1.5rem' }}>
                <li><strong>Address:</strong> 1 Buyide Avenue, Alagbado, Lagos, Nigeria</li>
                <li><strong>Latitude:</strong> 6.6750°N</li>
                <li><strong>Longitude:</strong> 3.2708°E</li>
                <li><strong>Timezone:</strong> West Africa Time (WAT) - UTC+1</li>
                <li><strong>Calculation Method:</strong> Islamic Society of North America (ISNA)</li>
              </ul>
            </div>
            <div className="card">
              <h3>Prayer Guidelines</h3>
              <ul style={{ paddingLeft: '1.5rem' }}>
                <li>Congregational prayers are held for all five daily prayers</li>
                <li>Friday Jumu'ah prayer begins at 1:00 PM</li>
                <li>Tarawih prayers during Ramadan after Isha</li>
                <li>Eid prayers are held in the main prayer hall</li>
                <li>Please arrive 10-15 minutes before prayer time</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Monthly Prayer Calendar */}
      <section className="section">
        <div className="container">
          <h2 className="section-title">July 2025 Prayer Calendar</h2>
          <div className="card">
            <div style={{ overflowX: 'auto' }}>
              <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.9rem' }}>
                <thead>
                  <tr style={{ background: '#1e3a8a', color: 'white' }}>
                    <th style={{ padding: '1rem', border: '1px solid #ddd' }}>Date</th>
                    <th style={{ padding: '1rem', border: '1px solid #ddd' }}>Fajr</th>
                    <th style={{ padding: '1rem', border: '1px solid #ddd' }}>Sunrise</th>
                    <th style={{ padding: '1rem', border: '1px solid #ddd' }}>Dhuhr</th>
                    <th style={{ padding: '1rem', border: '1px solid #ddd' }}>Asr</th>
                    <th style={{ padding: '1rem', border: '1px solid #ddd' }}>Maghrib</th>
                    <th style={{ padding: '1rem', border: '1px solid #ddd' }}>Isha</th>
                  </tr>
                </thead>
                <tbody>
                  {Array.from({ length: 7 }, (_, i) => {
                    const date = new Date(2025, 6, i + 1); // July 2025
                    return (
                      <tr key={i} style={{ background: i % 2 === 0 ? '#f8fafc' : 'white' }}>
                        <td style={{ padding: '0.8rem', border: '1px solid #ddd', fontWeight: 'bold' }}>
                          {date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                        </td>
                        <td style={{ padding: '0.8rem', border: '1px solid #ddd' }}>05:13</td>
                        <td style={{ padding: '0.8rem', border: '1px solid #ddd' }}>06:31</td>
                        <td style={{ padding: '0.8rem', border: '1px solid #ddd' }}>12:47</td>
                        <td style={{ padding: '0.8rem', border: '1px solid #ddd' }}>16:15</td>
                        <td style={{ padding: '0.8rem', border: '1px solid #ddd' }}>19:04</td>
                        <td style={{ padding: '0.8rem', border: '1px solid #ddd' }}>20:15</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
            <p style={{ textAlign: 'center', marginTop: '1rem', color: '#666', fontSize: '0.9rem' }}>
              Prayer times may vary by ±2 minutes. Please check with the mosque for exact congregation times.
            </p>
          </div>
        </div>
      </section>

      {/* Qibla Direction */}
      <section className="section" style={{ backgroundColor: '#f8fafc' }}>
        <div className="container">
          <h2 className="section-title">Qibla Direction</h2>
          <div className="card" style={{ textAlign: 'center' }}>
            <h3>Direction to Mecca from Alagbado, Lagos</h3>
            <div style={{ 
              width: '200px', 
              height: '200px', 
              border: '3px solid #1e3a8a', 
              borderRadius: '50%', 
              margin: '2rem auto',
              position: 'relative',
              background: 'linear-gradient(45deg, #f8fafc, #e2e8f0)'
            }}>
              <div style={{
                position: 'absolute',
                top: '50%',
                left: '50%',
                transform: 'translate(-50%, -50%) rotate(57deg)',
                width: '3px',
                height: '80px',
                background: '#1e3a8a',
                transformOrigin: 'bottom'
              }}></div>
              <div style={{
                position: 'absolute',
                top: '10px',
                left: '50%',
                transform: 'translateX(-50%)',
                fontSize: '0.8rem',
                fontWeight: 'bold'
              }}>N</div>
            </div>
            <p><strong>Qibla Direction:</strong> 57° Northeast</p>
            <p style={{ color: '#666', fontSize: '0.9rem', marginTop: '1rem' }}>
              The Qibla direction from Alagbado, Lagos to the Kaaba in Mecca, Saudi Arabia
            </p>
            <div className="arabic-text" style={{ marginTop: '1rem' }}>
              وَحَيْثُ مَا كُنتُمْ فَوَلُّوا وُجُوهَكُمْ شَطْرَهُ
            </div>
            <p style={{ fontStyle: 'italic', fontSize: '0.9rem' }}>
              "And wherever you are, turn your faces toward it" - Quran 2:144
            </p>
          </div>
        </div>
      </section>
    </div>
  );
};

export default PrayerTimes;

