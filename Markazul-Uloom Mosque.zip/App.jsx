import React, { useState, useEffect } from 'react';
import './App.css';
import Header from './components/Header';
import Home from './components/Home';
import About from './components/About';
import Services from './components/Services';
import PrayerTimes from './components/PrayerTimes';
import Anniversary from './components/Anniversary';
import Teachers from './components/Teachers';
import MasjidProject from './components/MasjidProject';
import Donation from './components/Donation';
import Contact from './components/Contact';
import Footer from './components/Footer';

function App() {
  const [currentPage, setCurrentPage] = useState('home');

  const renderPage = () => {
    switch (currentPage) {
      case 'home':
        return <Home />;
      case 'about':
        return <About />;
      case 'services':
        return <Services />;
      case 'prayer-times':
        return <PrayerTimes />;
      case 'anniversary':
        return <Anniversary />;
      case 'teachers':
        return <Teachers />;
      case 'masjid-project':
        return <MasjidProject />;
      case 'donation':
        return <Donation />;
      case 'contact':
        return <Contact />;
      default:
        return <Home />;
    }
  };

  return (
    <div className="App">
      <Header currentPage={currentPage} setCurrentPage={setCurrentPage} />
      <main>
        {renderPage()}
      </main>
      <Footer />
    </div>
  );
}

export default App;

