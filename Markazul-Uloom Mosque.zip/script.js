function showPage(pageId) {
    // Hide all pages
    document.querySelectorAll(".page").forEach(page => {
        page.classList.remove("active");
    });

    // Deactivate all navigation buttons
    document.querySelectorAll(".nav-btn").forEach(button => {
        button.classList.remove("active");
    });

    // Show the selected page and activate its button
    const selectedPage = document.getElementById(pageId + "-page");
    const selectedButton = document.getElementById(pageId + "-btn");

    if (selectedPage) {
        selectedPage.classList.add("active");
    }
    if (selectedButton) {
        selectedButton.classList.add("active");
    }
}

// Handle initial page load
window.addEventListener("DOMContentLoaded", () => {
    showPage("home");
});