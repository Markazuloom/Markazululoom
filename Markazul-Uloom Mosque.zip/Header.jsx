import React from 'react';

const Header = ({ currentPage, setCurrentPage }) => {
  const navItems = [
    { id: 'home', label: 'Home' },
    { id: 'about', label: 'About Us' },
    { id: 'teachers', label: 'Our Teachers' },
    { id: 'services', label: 'Services' },
    { id: 'prayer-times', label: 'Prayer Times' },
    { id: 'masjid-project', label: 'Masjid Project' },
    { id: 'anniversary', label: '40th Anniversary' },
    { id: 'donation', label: 'Donate' },
    { id: 'contact', label: 'Contact' }
  ];

  return (
    <header className="header">
      <div className="header-content">
        <div className="logo">
          <img 
            src="/images/logo.jpg" 
            alt="Markazul-Uloom Logo" 
            style={{ 
              height: '60px', 
              width: 'auto', 
              marginRight: '1rem',
              borderRadius: '5px'
            }} 
          />
          <div>
            <h1>Markazul-Uloom</h1>
            <p>Mosque and Arabic & Islamic Studies</p>
          </div>
        </div>
        <nav className="nav">
          {navItems.map(item => (
            <button
              key={item.id}
              className={currentPage === item.id ? 'active' : ''}
              onClick={() => setCurrentPage(item.id)}
            >
              {item.label}
            </button>
          ))}
        </nav>
      </div>
    </header>
  );
};

export default Header;

