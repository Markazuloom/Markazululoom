import React from 'react';

const Anniversary = () => {
  const milestones = [
    {
      year: '1985',
      title: 'Foundation',
      description: 'Markazul-Uloom was established as a small Islamic study center in Alagbado, Lagos, with the vision of providing authentic Islamic education to the local community.'
    },
    {
      year: '1990',
      title: 'First Graduation',
      description: 'The first batch of students completed their Islamic studies program, marking the beginning of our educational legacy.'
    },
    {
      year: '1995',
      title: 'Expansion',
      description: 'Construction of additional classrooms and the main prayer hall to accommodate the growing number of students and worshippers.'
    },
    {
      year: '2000',
      title: 'Arabic Department',
      description: 'Establishment of a dedicated Arabic language department with qualified teachers from various Arabic-speaking countries.'
    },
    {
      year: '2005',
      title: 'Community Outreach',
      description: 'Launch of community outreach programs including free medical clinics, literacy programs, and social welfare initiatives.'
    },
    {
      year: '2010',
      title: 'Modern Facilities',
      description: 'Renovation and modernization of facilities including a new library, computer lab, and improved dormitory facilities.'
    },
    {
      year: '2015',
      title: '30th Anniversary',
      description: 'Celebrated three decades of service with a grand symposium attended by Islamic scholars from across Nigeria and West Africa.'
    },
    {
      year: '2020',
      title: 'Digital Learning',
      description: 'Introduction of digital learning platforms and online classes, especially during the global pandemic, ensuring continuity of education.'
    },
    {
      year: '2025',
      title: '40th Anniversary',
      description: 'Celebrating four decades of excellence in Islamic education and community service, with over 2,000 graduates serving communities worldwide.'
    }
  ];

  const achievements = [
    {
      number: '2000+',
      title: 'Graduates',
      description: 'Alumni serving in various capacities across Nigeria and beyond'
    },
    {
      number: '500+',
      title: 'Current Students',
      description: 'Students enrolled in various Islamic studies programs'
    },
    {
      number: '40',
      title: 'Years of Service',
      description: 'Four decades of continuous Islamic education'
    },
    {
      number: '50+',
      title: 'Qualified Teachers',
      description: 'Experienced educators in Islamic and Arabic studies'
    }
  ];

  return (
    <div className="anniversary-page">
      {/* Hero Section */}
      <section className="anniversary-hero">
        <div className="container">
          <div className="bismillah arabic-text" style={{ color: '#ffd700', fontSize: '2rem' }}>
            بِسْمِ اللَّهِ الرَّحْمَنِ الرَّحِيم
          </div>
          
          {/* Official 40th Anniversary Logo */}
          <div style={{ display: 'flex', justifyContent: 'center', margin: '2rem 0' }}>
            <img 
              src="/images/40th-anniversary-logo.jpg" 
              alt="Markazul-Uloom 40th Anniversary Logo" 
              style={{ 
                width: '300px', 
                height: '300px', 
                objectFit: 'contain',
                filter: 'drop-shadow(0 10px 20px rgba(0,0,0,0.3))'
              }} 
            />
          </div>
          
          <h1 style={{ fontSize: '3rem', margin: '1rem 0', textShadow: '3px 3px 6px rgba(0,0,0,0.7)' }}>
            Celebrating 40 Years of Excellence
          </h1>
          <p style={{ fontSize: '1.5rem', maxWidth: '800px', margin: '0 auto 2rem' }}>
            Four Decades of Islamic Education and Community Service (1985-2025)
          </p>
          <div className="arabic-text" style={{ color: '#ffd700', fontSize: '1.5rem' }}>
            أربعون عاماً من التميز في التعليم الإسلامي
          </div>
          <p style={{ fontSize: '1.2rem', marginTop: '2rem', fontStyle: 'italic' }}>
            Markaz-ul-Uloom Otubu/Alagbado - A Journey of Faith, Knowledge, and Service
          </p>
        </div>
      </section>

      {/* Achievements Section */}
      <section className="section">
        <div className="container">
          <h2 className="section-title">Our Achievements</h2>
          <div className="grid grid-4">
            {achievements.map((achievement, index) => (
              <div key={index} className="card" style={{ textAlign: 'center' }}>
                <div style={{ 
                  fontSize: '3rem', 
                  fontWeight: 'bold', 
                  color: '#1e3a8a', 
                  marginBottom: '1rem' 
                }}>
                  {achievement.number}
                </div>
                <h3 style={{ marginBottom: '1rem' }}>{achievement.title}</h3>
                <p style={{ color: '#666' }}>{achievement.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Timeline Section */}
      <section className="section" style={{ backgroundColor: '#f8fafc' }}>
        <div className="container">
          <h2 className="section-title">Our Journey Through Time</h2>
          <div className="timeline">
            {milestones.map((milestone, index) => (
              <div key={index} className="timeline-item">
                <div className="card">
                  <div style={{ 
                    display: 'flex', 
                    alignItems: 'center', 
                    gap: '1rem', 
                    marginBottom: '1rem' 
                  }}>
                    <div style={{ 
                      background: 'linear-gradient(135deg, #1e3a8a 0%, #3b82f6 100%)',
                      color: 'white',
                      padding: '0.5rem 1rem',
                      borderRadius: '20px',
                      fontWeight: 'bold',
                      fontSize: '1.1rem'
                    }}>
                      {milestone.year}
                    </div>
                    <h3 style={{ margin: 0, color: '#1e3a8a' }}>{milestone.title}</h3>
                  </div>
                  <p>{milestone.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Vision for the Future */}
      <section className="section">
        <div className="container">
          <h2 className="section-title">Vision for the Future</h2>
          <div className="grid grid-2">
            <div className="card">
              <h3>Next Decade Goals (2025-2035)</h3>
              <ul style={{ paddingLeft: '1.5rem' }}>
                <li>Establish satellite campuses in other Nigerian states</li>
                <li>Launch online Islamic education platform for global reach</li>
                <li>Develop specialized programs in Islamic finance and economics</li>
                <li>Create a research center for Islamic studies</li>
                <li>Expand community development programs</li>
                <li>Build partnerships with international Islamic universities</li>
              </ul>
            </div>
            <div className="card">
              <h3>Continuing Our Legacy</h3>
              <p>
                As we celebrate 40 years of service, we remain committed to our founding principles 
                of providing authentic Islamic education while adapting to modern educational needs. 
                Our vision for the future includes expanding our reach through technology, 
                strengthening community partnerships, and continuing to produce graduates who 
                contribute positively to society.
              </p>
              <div className="arabic-text" style={{ margin: '1.5rem 0' }}>
                وَقُل رَّبِّ زِدْنِي عِلْماً
              </div>
              <p style={{ fontStyle: 'italic', textAlign: 'center' }}>
                "And say: My Lord, increase me in knowledge" - Quran 20:114
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Anniversary Events */}
      <section className="section" style={{ backgroundColor: '#f8fafc' }}>
        <div className="container">
          <h2 className="section-title">40th Anniversary Celebrations</h2>
          <div className="card" style={{ background: 'linear-gradient(135deg, #1e3a8a 0%, #3b82f6 100%)', color: 'white' }}>
            <h3 style={{ color: 'white', textAlign: 'center', marginBottom: '2rem' }}>
              Join Us in Celebrating This Historic Milestone
            </h3>
            <div className="grid grid-3">
              <div style={{ textAlign: 'center', padding: '1rem' }}>
                <h4 style={{ color: '#ffd700', marginBottom: '1rem' }}>Grand Symposium</h4>
                <p>International Islamic scholars gathering</p>
                <p><strong>Date:</strong> December 15-17, 2025</p>
              </div>
              <div style={{ textAlign: 'center', padding: '1rem' }}>
                <h4 style={{ color: '#ffd700', marginBottom: '1rem' }}>Alumni Reunion</h4>
                <p>Celebrating our graduates' achievements</p>
                <p><strong>Date:</strong> December 20, 2025</p>
              </div>
              <div style={{ textAlign: 'center', padding: '1rem' }}>
                <h4 style={{ color: '#ffd700', marginBottom: '1rem' }}>Community Festival</h4>
                <p>Cultural and educational exhibitions</p>
                <p><strong>Date:</strong> December 22, 2025</p>
              </div>
            </div>
            <div style={{ textAlign: 'center', marginTop: '2rem' }}>
              <button className="btn btn-secondary">Register for Events</button>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="section">
        <div className="container">
          <h2 className="section-title">Voices from Our Community</h2>
          <div className="grid grid-2">
            <div className="card">
              <blockquote style={{ 
                fontSize: '1.1rem', 
                fontStyle: 'italic', 
                marginBottom: '1rem',
                borderLeft: '4px solid #1e3a8a',
                paddingLeft: '1rem'
              }}>
                "Markazul-Uloom shaped not just my Islamic knowledge, but my character and worldview. 
                The education I received here has been invaluable in my journey as an Islamic scholar."
              </blockquote>
              <p><strong>Dr. Amina Hassan</strong> - Class of 1995, Islamic Studies Professor</p>
            </div>
            <div className="card">
              <blockquote style={{ 
                fontSize: '1.1rem', 
                fontStyle: 'italic', 
                marginBottom: '1rem',
                borderLeft: '4px solid #1e3a8a',
                paddingLeft: '1rem'
              }}>
                "The comprehensive Arabic program at Markazul-Uloom opened doors for me to study 
                in Saudi Arabia and now serve as an Imam in my community. Forever grateful!"
              </blockquote>
              <p><strong>Imam Yusuf Adebayo</strong> - Class of 2008, Community Leader</p>
            </div>
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="section" style={{ backgroundColor: '#f8fafc' }}>
        <div className="container">
          <div className="card" style={{ textAlign: 'center' }}>
            <h2 style={{ color: '#1e3a8a', marginBottom: '1rem' }}>Be Part of Our Legacy</h2>
            <p style={{ fontSize: '1.2rem', marginBottom: '2rem', maxWidth: '600px', margin: '0 auto 2rem' }}>
              Whether you're an alumnus, a supporter, or someone interested in Islamic education, 
              we invite you to be part of our continuing journey.
            </p>
            <div className="arabic-text" style={{ fontSize: '1.3rem', marginBottom: '2rem' }}>
              وَمَن أَحْيَاهَا فَكَأَنَّمَا أَحْيَا النَّاسَ جَمِيعاً
            </div>
            <p style={{ fontStyle: 'italic', marginBottom: '2rem' }}>
              "And whoever saves a life, it is as if he has saved all of mankind" - Quran 5:32
            </p>
            <div style={{ display: 'flex', gap: '1rem', justifyContent: 'center', flexWrap: 'wrap' }}>
              <button className="btn">Support Our Mission</button>
              <button className="btn btn-secondary">Alumni Registration</button>
              <button className="btn">Visit Our Campus</button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Anniversary;

