import React from 'react';

const Footer = () => {
  return (
    <footer className="footer">
      <div className="container">
        <div className="footer-content">
          <div className="footer-section">
            <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', marginBottom: '1rem' }}>
              <img 
                src="/images/logo.jpg" 
                alt="Markazul-Uloom Logo" 
                style={{ 
                  height: '50px', 
                  width: 'auto', 
                  borderRadius: '5px'
                }} 
              />
              <div>
                <h3>Markazul-Uloom</h3>
                <p style={{ margin: 0, fontSize: '0.9rem' }}>Mosque and Arabic & Islamic Studies</p>
              </div>
            </div>
            <div className="arabic-text" style={{ fontSize: '1rem', marginBottom: '1rem', color: '#ffd700' }}>
              مركز العلوم للدراسات الإسلامية والعربية
            </div>
            <p>
              Serving the Muslim community in Alagbado, Lagos, Nigeria since 1985. 
              Providing authentic Islamic education and spiritual guidance for over four decades.
            </p>
            <div className="arabic-text" style={{ fontSize: '1rem', marginTop: '1rem', color: '#ffd700' }}>
              وَقُل رَّبِّ زِدْنِي عِلْماً
            </div>
            <p style={{ fontStyle: 'italic', fontSize: '0.9rem' }}>
              "And say: My Lord, increase me in knowledge" - Quran 20:114
            </p>
          </div>

          <div className="footer-section">
            <h3>Quick Links</h3>
            <ul>
              <li><a href="#home">Home</a></li>
              <li><a href="#about">About Us</a></li>
              <li><a href="#teachers">Our Teachers</a></li>
              <li><a href="#services">Services</a></li>
              <li><a href="#prayer-times">Prayer Times</a></li>
              <li><a href="#anniversary">40th Anniversary</a></li>
              <li><a href="#masjid-project">Masjid Project</a></li>
              <li><a href="#donation">Donate</a></li>
            </ul>
          </div>

          <div className="footer-section">
            <h3>Contact Information</h3>
            <div style={{ marginBottom: '1rem' }}>
              <strong>📍 Address:</strong>
              <p>1 Buyide Avenue<br/>Alagbado, Lagos State<br/>Nigeria</p>
            </div>
            <div style={{ marginBottom: '1rem' }}>
              <strong>📞 Phone:</strong>
              <p>+234 803 123 4567<br/>+234 806 789 0123</p>
            </div>
            <div style={{ marginBottom: '1rem' }}>
              <strong>📧 Email:</strong>
              <p>info@markazul-uloom.org<br/>admissions@markazul-uloom.org</p>
            </div>
          </div>

          <div className="footer-section">
            <h3>Prayer Times Today</h3>
            <div style={{ background: 'rgba(255, 255, 255, 0.1)', padding: '1rem', borderRadius: '10px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.5rem' }}>
                <span>Fajr (الفجر)</span>
                <span style={{ color: '#ffd700' }}>5:13 AM</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.5rem' }}>
                <span>Dhuhr (الظهر)</span>
                <span style={{ color: '#ffd700' }}>12:47 PM</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.5rem' }}>
                <span>Asr (العصر)</span>
                <span style={{ color: '#ffd700' }}>4:15 PM</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.5rem' }}>
                <span>Maghrib (المغرب)</span>
                <span style={{ color: '#ffd700' }}>7:04 PM</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <span>Isha (العشاء)</span>
                <span style={{ color: '#ffd700' }}>8:15 PM</span>
              </div>
            </div>
            <p style={{ fontSize: '0.8rem', marginTop: '1rem', opacity: 0.8 }}>
              Times for Alagbado, Lagos, Nigeria
            </p>
          </div>
        </div>

        <div className="footer-bottom">
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '1rem' }}>
            <div>
              <p>&copy; 2025 Markazul-Uloom Mosque and Arabic & Islamic Studies. All rights reserved.</p>
              <div className="arabic-text" style={{ fontSize: '0.9rem' }}>
                جميع الحقوق محفوظة لمركز العلوم ٢٠٢٥
              </div>
            </div>
            <div style={{ display: 'flex', gap: '1rem', alignItems: 'center' }}>
              <span>Follow us:</span>
              <a href="https://www.facebook.com/marcazululoomalagbado/" target="_blank" rel="noopener noreferrer" style={{ color: '#ffd700', textDecoration: 'none' }}>
                📘 Facebook
              </a>
              <a href="#" style={{ color: '#ffd700', textDecoration: 'none' }}>
                💬 WhatsApp
              </a>
              <a href="#" style={{ color: '#ffd700', textDecoration: 'none' }}>
                📧 Email
              </a>
            </div>
          </div>
          
          <div style={{ textAlign: 'center', marginTop: '2rem', padding: '1rem', background: 'rgba(255, 255, 255, 0.1)', borderRadius: '10px' }}>
            <div className="arabic-text" style={{ fontSize: '1.2rem', marginBottom: '0.5rem', color: '#ffd700' }}>
              رَبَّنَا تَقَبَّلْ مِنَّا إِنَّكَ أَنتَ السَّمِيعُ الْعَلِيمُ
            </div>
            <p style={{ fontStyle: 'italic', fontSize: '0.9rem' }}>
              "Our Lord, accept [this] from us. Indeed You are the Hearing, the Knowing." - Quran 2:127
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;

