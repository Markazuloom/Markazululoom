import React from 'react';

const Home = () => {
  return (
    <div className="home">
      {/* Hero Section */}
      <section className="mosque-hero">
        <div className="islamic-pattern"></div>
        <div className="container">
          <div className="bismillah arabic-text">بِسْمِ اللَّهِ الرَّحْمَنِ الرَّحِيم</div>
          <h1 className="fade-in-up">Markazul-Uloom</h1>
          <p className="fade-in-up">
            Mosque and Arabic & Islamic Studies - Serving the Muslim community in Alagbado, Lagos, Nigeria since 1985
          </p>
          <div className="arabic-text">مرحباً بكم في مركز العلوم</div>
        </div>
      </section>

      {/* Welcome Section */}
      <section className="section">
        <div className="container">
          <h2 className="section-title">Welcome to Markazul-Uloom</h2>
          <div className="grid grid-2">
            <div className="card">
              <h3>Our Mission</h3>
              <p>
                To provide comprehensive Islamic education, foster spiritual growth, and serve as a center 
                for worship and community development. We are committed to teaching the Quran, Hadith, 
                Arabic language, and Islamic jurisprudence according to authentic Islamic traditions.
              </p>
            </div>
            <div className="card">
              <h3>Our Vision</h3>
              <p>
                To be a leading Islamic educational institution that produces knowledgeable, righteous, 
                and productive Muslims who contribute positively to society while maintaining strong 
                Islamic values and principles.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* About Our Imam Section */}
      <section className="section" style={{ backgroundColor: '#f8fafc' }}>
        <div className="container">
          <h2 className="section-title">About Our Imam</h2>
          <div className="grid grid-2">
            <div className="card">
              <div style={{ 
                width: '150px', 
                height: '150px', 
                borderRadius: '50%', 
                background: 'linear-gradient(135deg, #1e3a8a 0%, #3b82f6 100%)',
                margin: '0 auto 2rem',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                color: 'white',
                fontSize: '3rem',
                fontWeight: 'bold'
              }}>
                إ
              </div>
              <h3 style={{ textAlign: 'center', marginBottom: '1rem' }}>Sheikh Dr. Abass Abdul Azeez</h3>
              <p style={{ textAlign: 'center', fontStyle: 'italic', color: '#666', marginBottom: '1rem' }}>
                Mudir (Director) - Markazul-Uloom
              </p>
              <div className="arabic-text" style={{ fontSize: '1rem', marginBottom: '1rem' }}>
                الشيخ الدكتور عباس عبد العزيز
              </div>
            </div>
            <div className="card">
              <h3>Leadership & Scholarship</h3>
              <p>
                Sheikh Dr. Abass Abdul Azeez serves as the esteemed Mudir (Director) of Markazul-Uloom, 
                bringing decades of Islamic scholarship and educational leadership to our institution. 
                With his Ph.D. in Islamic Studies, he has dedicated his life to advancing Islamic education 
                and spiritual guidance.
              </p>
              <h4 style={{ color: '#1e3a8a', marginTop: '1.5rem', marginBottom: '1rem' }}>Qualifications & Experience</h4>
              <ul style={{ paddingLeft: '1.5rem' }}>
                <li>Ph.D. in Islamic Studies</li>
                <li>Extensive knowledge in Quranic interpretation (Tafsir)</li>
                <li>Expert in Hadith sciences and Islamic jurisprudence (Fiqh)</li>
                <li>Fluent in Arabic, English, and local Nigerian languages</li>
                <li>Over 20 years of teaching and administrative experience</li>
              </ul>
            </div>
          </div>
          
          <div className="card" style={{ marginTop: '2rem' }}>
            <h3>Spiritual Guidance & Community Leadership</h3>
            <div className="grid grid-2">
              <div>
                <h4 style={{ color: '#1e3a8a', marginBottom: '1rem' }}>Teaching Philosophy</h4>
                <p>
                  Sheikh Dr. Abass believes in combining traditional Islamic scholarship with contemporary 
                  understanding, making Islamic teachings accessible and relevant to modern Muslim life. 
                  His approach emphasizes both spiritual development and practical application of Islamic principles.
                </p>
              </div>
              <div>
                <h4 style={{ color: '#1e3a8a', marginBottom: '1rem' }}>Community Impact</h4>
                <p>
                  Under his leadership, Markazul-Uloom has grown from a small Islamic center to a 
                  comprehensive educational institution serving hundreds of students. He regularly 
                  conducts Tafsir sessions, Friday sermons, and community outreach programs.
                </p>
              </div>
            </div>
            
            <div style={{ marginTop: '2rem', padding: '1.5rem', backgroundColor: '#f1f5f9', borderRadius: '10px' }}>
              <h4 style={{ color: '#1e3a8a', marginBottom: '1rem', textAlign: 'center' }}>Weekly Programs</h4>
              <div className="grid grid-3">
                <div style={{ textAlign: 'center' }}>
                  <strong>Friday Khutbah</strong>
                  <p>Weekly Friday sermons in Arabic and English</p>
                </div>
                <div style={{ textAlign: 'center' }}>
                  <strong>Tafsir Sessions</strong>
                  <p>Quranic interpretation classes every Saturday</p>
                </div>
                <div style={{ textAlign: 'center' }}>
                  <strong>Islamic Counseling</strong>
                  <p>Personal guidance and spiritual counseling</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Quick Prayer Times */}
      <section className="section">
        <div className="container">
          <h2 className="section-title">Today's Prayer Times - Alagbado, Lagos</h2>
          <div className="prayer-times-grid">
            <div className="prayer-time-card">
              <h3>Fajr</h3>
              <div className="time">5:13 AM</div>
              <div className="arabic">الفجر</div>
            </div>
            <div className="prayer-time-card">
              <h3>Dhuhr</h3>
              <div className="time">12:47 PM</div>
              <div className="arabic">الظهر</div>
            </div>
            <div className="prayer-time-card">
              <h3>Asr</h3>
              <div className="time">4:15 PM</div>
              <div className="arabic">العصر</div>
            </div>
            <div className="prayer-time-card">
              <h3>Maghrib</h3>
              <div className="time">7:04 PM</div>
              <div className="arabic">المغرب</div>
            </div>
            <div className="prayer-time-card">
              <h3>Isha</h3>
              <div className="time">8:15 PM</div>
              <div className="arabic">العشاء</div>
            </div>
          </div>
          <div style={{ textAlign: 'center', marginTop: '2rem' }}>
            <p style={{ color: '#666', fontSize: '0.9rem' }}>
              Prayer times are calculated for Alagbado, Lagos, Nigeria (Latitude: 6.6750, Longitude: 3.2708)
            </p>
          </div>
        </div>
      </section>

      {/* Our Beautiful Campus */}
      <section className="section" style={{ backgroundColor: '#f8fafc' }}>
        <div className="container">
          <h2 className="section-title">Our Beautiful Campus</h2>
          <div className="grid grid-2">
            <div className="card">
              <img 
                src="/images/school-building.jpg" 
                alt="Markazul-Uloom Campus" 
                style={{ width: '100%', height: '300px', objectFit: 'cover', borderRadius: '10px', marginBottom: '1.5rem' }}
              />
              <h3>Modern Islamic Architecture</h3>
              <p>
                Our campus features stunning Islamic architecture with blue and white buildings 
                adorned with golden accents. The design harmoniously blends traditional Islamic 
                elements with modern educational facilities, creating an inspiring environment 
                for learning and worship.
              </p>
            </div>
            <div className="card">
              <h3>Campus Facilities</h3>
              <div style={{ marginBottom: '1.5rem' }}>
                <h4 style={{ color: '#1e3a8a', marginBottom: '1rem' }}>Educational Buildings</h4>
                <ul style={{ paddingLeft: '1.5rem', marginBottom: '1rem' }}>
                  <li>Modern classrooms with audio-visual equipment</li>
                  <li>Specialized Arabic language laboratories</li>
                  <li>Computer and technology centers</li>
                  <li>Comprehensive Islamic library</li>
                  <li>Research and study halls</li>
                </ul>
              </div>
              
              <div style={{ marginBottom: '1.5rem' }}>
                <h4 style={{ color: '#1e3a8a', marginBottom: '1rem' }}>Worship Facilities</h4>
                <ul style={{ paddingLeft: '1.5rem', marginBottom: '1rem' }}>
                  <li>Main mosque with beautiful blue dome</li>
                  <li>Separate prayer areas for men and women</li>
                  <li>Modern ablution facilities</li>
                  <li>Peaceful courtyards for reflection</li>
                </ul>
              </div>
              
              <div>
                <h4 style={{ color: '#1e3a8a', marginBottom: '1rem' }}>Student Amenities</h4>
                <ul style={{ paddingLeft: '1.5rem' }}>
                  <li>Comfortable dormitory accommodation</li>
                  <li>Halal cafeteria and dining facilities</li>
                  <li>Sports and recreation areas</li>
                  <li>Medical clinic and health services</li>
                </ul>
              </div>
            </div>
          </div>
          
          <div className="card" style={{ marginTop: '2rem', textAlign: 'center', background: 'linear-gradient(135deg, #1e3a8a 0%, #3b82f6 100%)', color: 'white' }}>
            <h3 style={{ color: 'white', marginBottom: '1rem' }}>Campus Tours Available</h3>
            <p style={{ marginBottom: '2rem' }}>
              Experience our beautiful campus firsthand. We offer guided tours for prospective students, 
              parents, and visitors interested in learning more about our facilities and programs.
            </p>
            <div className="arabic-text" style={{ color: '#ffd700', fontSize: '1.2rem', marginBottom: '1rem' }}>
              مرحباً بكم في حرمنا الجامعي
            </div>
            <button className="btn btn-secondary">Schedule a Campus Tour</button>
          </div>
        </div>
      </section>

      {/* Services Overview */}
      <section className="section">
        <div className="container">
          <h2 className="section-title">Our Services</h2>
          <div className="grid grid-3">
            <div className="card">
              <h3>Islamic Education</h3>
              <p>
                Comprehensive Arabic and Islamic studies curriculum including Quran memorization, 
                Hadith studies, Islamic jurisprudence, and Arabic language instruction.
              </p>
            </div>
            <div className="card">
              <h3>Daily Prayers</h3>
              <p>
                Five daily congregational prayers with experienced Imams leading the community 
                in worship and spiritual reflection.
              </p>
            </div>
            <div className="card">
              <h3>Community Programs</h3>
              <p>
                Regular Islamic lectures, youth programs, women's circles, and community 
                outreach initiatives serving the broader Alagbado community.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="section">
        <div className="container">
          <div className="card" style={{ textAlign: 'center', background: 'linear-gradient(135deg, #1e3a8a 0%, #3b82f6 100%)', color: 'white' }}>
            <h2 style={{ color: 'white', marginBottom: '1rem' }}>Join Our Community</h2>
            <p style={{ fontSize: '1.2rem', marginBottom: '2rem' }}>
              Experience the warmth of Islamic brotherhood and sisterhood at Markazul-Uloom. 
              All are welcome to join our prayers, classes, and community events.
            </p>
            <div className="arabic-text" style={{ color: '#ffd700', fontSize: '1.5rem', marginBottom: '2rem' }}>
              وَتَعَاوَنُوا عَلَى الْبِرِّ وَالتَّقْوَىٰ
            </div>
            <p style={{ fontStyle: 'italic', marginBottom: '2rem' }}>
              "And cooperate in righteousness and piety" - Quran 5:2
            </p>
            <div style={{ display: 'flex', gap: '1rem', justifyContent: 'center', flexWrap: 'wrap' }}>
              <button className="btn btn-secondary">Visit Us Today</button>
              <button className="btn" style={{ background: 'rgba(255, 255, 255, 0.2)' }}>Learn More</button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;

