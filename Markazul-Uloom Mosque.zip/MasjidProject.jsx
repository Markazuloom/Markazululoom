import React from 'react';

const MasjidProject = () => {
  const projectPhases = [
    {
      phase: 'Phase 1',
      title: 'Foundation & Infrastructure',
      status: 'Completed',
      budget: '₦50,000,000',
      description: 'Site preparation, foundation laying, and basic infrastructure development',
      completion: '100%'
    },
    {
      phase: 'Phase 2',
      title: 'Main Prayer Hall Construction',
      status: 'In Progress',
      budget: '₦120,000,000',
      description: 'Construction of the main prayer hall with capacity for 2,000 worshippers',
      completion: '65%'
    },
    {
      phase: 'Phase 3',
      title: 'Minarets & Dome Installation',
      status: 'Upcoming',
      budget: '₦80,000,000',
      description: 'Installation of four minarets and the main dome with Islamic architectural details',
      completion: '0%'
    },
    {
      phase: 'Phase 4',
      title: 'Interior Design & Finishing',
      status: 'Planned',
      budget: '₦60,000,000',
      description: 'Islamic calligraphy, carpeting, lighting, and interior finishing work',
      completion: '0%'
    },
    {
      phase: 'Phase 5',
      title: 'Landscaping & External Works',
      status: 'Planned',
      budget: '₦30,000,000',
      description: 'Parking facilities, gardens, external lighting, and security systems',
      completion: '0%'
    }
  ];

  const features = [
    {
      icon: '🕌',
      title: 'Grand Prayer Hall',
      description: 'Main prayer hall accommodating 2,000 worshippers with modern acoustics and climate control'
    },
    {
      icon: '👥',
      title: 'Separate Women\'s Section',
      description: 'Dedicated prayer area for women with independent entrance and facilities'
    },
    {
      icon: '🎓',
      title: 'Educational Facilities',
      description: 'Integrated classrooms and lecture halls for continued Islamic education'
    },
    {
      icon: '📚',
      title: 'Expanded Library',
      description: 'State-of-the-art Islamic library with digital resources and study areas'
    },
    {
      icon: '🚿',
      title: 'Modern Ablution Areas',
      description: 'Spacious ablution facilities with temperature-controlled water systems'
    },
    {
      icon: '🏛️',
      title: 'Community Center',
      description: 'Multi-purpose hall for community events, weddings, and conferences'
    }
  ];

  const fundingBreakdown = [
    { source: 'Community Donations', amount: 180000000, percentage: 52 },
    { source: 'International Partners', amount: 100000000, percentage: 29 },
    { source: 'Government Support', amount: 40000000, percentage: 12 },
    { source: 'Corporate Sponsors', amount: 20000000, percentage: 6 }
  ];

  const totalBudget = 340000000;
  const raisedAmount = 220000000;
  const progressPercentage = Math.round((raisedAmount / totalBudget) * 100);

  return (
    <div className="masjid-project-page">
      {/* Hero Section */}
      <section className="section" style={{ background: 'linear-gradient(135deg, #1e3a8a 0%, #3b82f6 100%)', color: 'white' }}>
        <div className="container">
          <div style={{ textAlign: 'center' }}>
            <div className="bismillah arabic-text" style={{ color: '#ffd700', fontSize: '2rem' }}>
              بِسْمِ اللَّهِ الرَّحْمَنِ الرَّحِيم
            </div>
            <h1 style={{ fontSize: '3rem', margin: '2rem 0', color: 'white' }}>Masjid Expansion Project</h1>
            <p style={{ fontSize: '1.3rem', maxWidth: '800px', margin: '0 auto' }}>
              Building a magnificent house of Allah to serve our growing community for generations to come
            </p>
            <div className="arabic-text" style={{ color: '#ffd700', fontSize: '1.2rem', marginTop: '2rem' }}>
              مشروع توسعة المسجد
            </div>
            <div style={{ marginTop: '2rem', padding: '2rem', background: 'rgba(255, 255, 255, 0.1)', borderRadius: '10px', display: 'inline-block' }}>
              <div className="arabic-text" style={{ color: '#ffd700', fontSize: '1.5rem', marginBottom: '1rem' }}>
                إِنَّمَا يَعْمُرُ مَسَاجِدَ اللَّهِ مَنْ آمَنَ بِاللَّهِ وَالْيَوْمِ الْآخِرِ
              </div>
              <p style={{ fontStyle: 'italic' }}>
                "The mosques of Allah are only to be maintained by those who believe in Allah and the Last Day" - Quran 9:18
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Project Overview */}
      <section className="section">
        <div className="container">
          <div className="grid grid-2">
            <div>
              <h2 style={{ color: '#1e3a8a', marginBottom: '2rem' }}>Project Vision</h2>
              <div className="card">
                <img 
                  src="/images/masjid-project.jpg" 
                  alt="Masjid Expansion Project Rendering" 
                  style={{ width: '100%', height: '300px', objectFit: 'cover', borderRadius: '10px', marginBottom: '1.5rem' }}
                />
                <h3>A Modern Islamic Architectural Marvel</h3>
                <p>
                  Our masjid expansion project represents a harmonious blend of traditional Islamic architecture 
                  and modern functionality. The new facility will feature stunning blue domes, elegant white walls 
                  with golden accents, and four towering minarets that will serve as a beacon of faith in Alagbado.
                </p>
                <p>
                  This project is not just about expanding our physical space, but about creating a spiritual 
                  sanctuary that will inspire worship, learning, and community building for generations to come.
                </p>
              </div>
            </div>
            
            <div>
              <h2 style={{ color: '#1e3a8a', marginBottom: '2rem' }}>Funding Progress</h2>
              <div className="card">
                <div style={{ textAlign: 'center', marginBottom: '2rem' }}>
                  <div style={{ fontSize: '3rem', fontWeight: 'bold', color: '#1e3a8a' }}>
                    {progressPercentage}%
                  </div>
                  <p style={{ fontSize: '1.2rem', color: '#666' }}>Project Funded</p>
                </div>
                
                <div style={{ background: '#e2e8f0', borderRadius: '10px', height: '20px', marginBottom: '1rem' }}>
                  <div 
                    style={{ 
                      background: 'linear-gradient(90deg, #1e3a8a, #3b82f6)', 
                      height: '100%', 
                      borderRadius: '10px',
                      width: `${progressPercentage}%`,
                      transition: 'width 0.5s ease'
                    }}
                  ></div>
                </div>
                
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '2rem' }}>
                  <div>
                    <strong>Raised:</strong> ₦{raisedAmount.toLocaleString()}
                  </div>
                  <div>
                    <strong>Goal:</strong> ₦{totalBudget.toLocaleString()}
                  </div>
                </div>
                
                <div style={{ background: '#f8fafc', padding: '1.5rem', borderRadius: '10px' }}>
                  <h4 style={{ color: '#1e3a8a', marginBottom: '1rem' }}>Remaining Needed</h4>
                  <div style={{ fontSize: '2rem', fontWeight: 'bold', color: '#dc2626' }}>
                    ₦{(totalBudget - raisedAmount).toLocaleString()}
                  </div>
                  <p style={{ color: '#666', marginTop: '0.5rem' }}>
                    Help us reach our goal and complete this blessed project
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Project Features */}
      <section className="section" style={{ backgroundColor: '#f8fafc' }}>
        <div className="container">
          <h2 className="section-title">Project Features</h2>
          <div className="grid grid-3">
            {features.map((feature, index) => (
              <div key={index} className="card">
                <div style={{ fontSize: '3rem', textAlign: 'center', marginBottom: '1rem' }}>
                  {feature.icon}
                </div>
                <h3 style={{ textAlign: 'center', marginBottom: '1rem', color: '#1e3a8a' }}>
                  {feature.title}
                </h3>
                <p style={{ textAlign: 'center' }}>{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Project Phases */}
      <section className="section">
        <div className="container">
          <h2 className="section-title">Construction Phases</h2>
          <div className="timeline">
            {projectPhases.map((phase, index) => (
              <div key={index} className="timeline-item">
                <div className="card">
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem' }}>
                    <div>
                      <h3 style={{ color: '#1e3a8a', margin: 0 }}>{phase.phase}: {phase.title}</h3>
                      <p style={{ margin: '0.5rem 0', fontWeight: 'bold', color: phase.status === 'Completed' ? '#059669' : phase.status === 'In Progress' ? '#d97706' : '#6b7280' }}>
                        {phase.status}
                      </p>
                    </div>
                    <div style={{ textAlign: 'right' }}>
                      <div style={{ fontSize: '1.5rem', fontWeight: 'bold', color: '#1e3a8a' }}>
                        {phase.budget}
                      </div>
                      <div style={{ fontSize: '1.1rem', color: '#666' }}>
                        {phase.completion} Complete
                      </div>
                    </div>
                  </div>
                  
                  <p style={{ marginBottom: '1rem' }}>{phase.description}</p>
                  
                  <div style={{ background: '#e2e8f0', borderRadius: '5px', height: '8px' }}>
                    <div 
                      style={{ 
                        background: phase.status === 'Completed' ? '#059669' : phase.status === 'In Progress' ? '#d97706' : '#e2e8f0',
                        height: '100%', 
                        borderRadius: '5px',
                        width: phase.completion,
                        transition: 'width 0.5s ease'
                      }}
                    ></div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Funding Sources */}
      <section className="section" style={{ backgroundColor: '#f8fafc' }}>
        <div className="container">
          <h2 className="section-title">Funding Sources</h2>
          <div className="grid grid-2">
            <div className="card">
              <h3>Funding Breakdown</h3>
              {fundingBreakdown.map((source, index) => (
                <div key={index} style={{ marginBottom: '1.5rem' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.5rem' }}>
                    <span style={{ fontWeight: 'bold' }}>{source.source}</span>
                    <span style={{ color: '#1e3a8a', fontWeight: 'bold' }}>{source.percentage}%</span>
                  </div>
                  <div style={{ background: '#e2e8f0', borderRadius: '5px', height: '10px' }}>
                    <div 
                      style={{ 
                        background: 'linear-gradient(90deg, #1e3a8a, #3b82f6)',
                        height: '100%', 
                        borderRadius: '5px',
                        width: `${source.percentage}%`
                      }}
                    ></div>
                  </div>
                  <div style={{ fontSize: '0.9rem', color: '#666', marginTop: '0.5rem' }}>
                    ₦{source.amount.toLocaleString()}
                  </div>
                </div>
              ))}
            </div>
            
            <div className="card">
              <h3>How You Can Contribute</h3>
              <div style={{ marginBottom: '2rem' }}>
                <h4 style={{ color: '#1e3a8a', marginBottom: '1rem' }}>Donation Options:</h4>
                <ul style={{ paddingLeft: '1.5rem', marginBottom: '1.5rem' }}>
                  <li><strong>Brick Sponsorship:</strong> ₦1,000 per brick</li>
                  <li><strong>Pillar Sponsorship:</strong> ₦100,000 per pillar</li>
                  <li><strong>Window Sponsorship:</strong> ₦50,000 per window</li>
                  <li><strong>Dome Contribution:</strong> ₦5,000,000 for main dome</li>
                  <li><strong>Minaret Sponsorship:</strong> ₦10,000,000 per minaret</li>
                  <li><strong>Prayer Hall Section:</strong> ₦25,000,000</li>
                </ul>
                
                <div style={{ background: '#f1f5f9', padding: '1rem', borderRadius: '5px' }}>
                  <h4 style={{ color: '#1e3a8a', marginBottom: '0.5rem' }}>Special Recognition</h4>
                  <p style={{ fontSize: '0.9rem' }}>
                    Major contributors will be recognized with plaques and their names inscribed 
                    in the mosque's donor wall, ensuring their legacy for generations.
                  </p>
                </div>
              </div>
              
              <button className="btn" style={{ width: '100%', padding: '1rem' }}>
                Contribute to Masjid Project
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Project Timeline */}
      <section className="section">
        <div className="container">
          <h2 className="section-title">Project Timeline</h2>
          <div className="card">
            <div className="grid grid-4">
              <div style={{ textAlign: 'center', padding: '1rem' }}>
                <div style={{ fontSize: '2rem', fontWeight: 'bold', color: '#1e3a8a' }}>2023</div>
                <h4>Project Launch</h4>
                <p>Groundbreaking ceremony and foundation work</p>
              </div>
              <div style={{ textAlign: 'center', padding: '1rem' }}>
                <div style={{ fontSize: '2rem', fontWeight: 'bold', color: '#1e3a8a' }}>2024</div>
                <h4>Main Construction</h4>
                <p>Prayer hall and structural work in progress</p>
              </div>
              <div style={{ textAlign: 'center', padding: '1rem' }}>
                <div style={{ fontSize: '2rem', fontWeight: 'bold', color: '#1e3a8a' }}>2025</div>
                <h4>Architectural Details</h4>
                <p>Minarets, dome, and Islamic decorations</p>
              </div>
              <div style={{ textAlign: 'center', padding: '1rem' }}>
                <div style={{ fontSize: '2rem', fontWeight: 'bold', color: '#1e3a8a' }}>2026</div>
                <h4>Grand Opening</h4>
                <p>Completion and inaugural prayers</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Community Impact */}
      <section className="section" style={{ backgroundColor: '#f8fafc' }}>
        <div className="container">
          <h2 className="section-title">Community Impact</h2>
          <div className="grid grid-3">
            <div className="card" style={{ textAlign: 'center' }}>
              <div style={{ fontSize: '3rem', marginBottom: '1rem' }}>👥</div>
              <h3>2,000+</h3>
              <p>Worshippers capacity in the new prayer hall</p>
            </div>
            <div className="card" style={{ textAlign: 'center' }}>
              <div style={{ fontSize: '3rem', marginBottom: '1rem' }}>🎓</div>
              <h3>500+</h3>
              <p>Additional students in expanded educational facilities</p>
            </div>
            <div className="card" style={{ textAlign: 'center' }}>
              <div style={{ fontSize: '3rem', marginBottom: '1rem' }}>🤝</div>
              <h3>10,000+</h3>
              <p>Community members served through various programs</p>
            </div>
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="section">
        <div className="container">
          <div className="card" style={{ textAlign: 'center', background: 'linear-gradient(135deg, #1e3a8a 0%, #3b82f6 100%)', color: 'white' }}>
            <h2 style={{ color: 'white', marginBottom: '1rem' }}>Be Part of This Historic Project</h2>
            <p style={{ fontSize: '1.2rem', marginBottom: '2rem' }}>
              Your contribution to this masjid project is an investment in the spiritual future of our community. 
              Every donation, no matter the size, brings us closer to completing this house of Allah.
            </p>
            <div className="arabic-text" style={{ color: '#ffd700', fontSize: '1.5rem', marginBottom: '2rem' }}>
              مَنْ بَنَى مَسْجِدًا يَبْتَغِي بِهِ وَجْهَ اللَّهِ بَنَى اللَّهُ لَهُ مِثْلَهُ فِي الْجَنَّةِ
            </div>
            <p style={{ fontStyle: 'italic', marginBottom: '2rem' }}>
              "Whoever builds a mosque seeking Allah's pleasure, Allah will build for him a similar house in Paradise" - Hadith
            </p>
            <div style={{ display: 'flex', gap: '1rem', justifyContent: 'center', flexWrap: 'wrap' }}>
              <button className="btn btn-secondary">Donate Now</button>
              <button className="btn" style={{ background: 'rgba(255, 255, 255, 0.2)' }}>Download Project Brochure</button>
              <button className="btn" style={{ background: 'rgba(255, 255, 255, 0.2)' }}>Schedule Site Visit</button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default MasjidProject;

