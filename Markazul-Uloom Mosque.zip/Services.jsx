import React from 'react';

const Services = () => {
  const educationalServices = [
    {
      title: 'Quranic Studies',
      arabicTitle: 'الدراسات القرآنية',
      description: 'Comprehensive Quranic education including memorization (Hifz), recitation (Qira\'at), and interpretation (Tafsir)',
      features: ['Quran memorization programs', 'Tajweed and proper recitation', 'Tafsir and interpretation', 'Quranic Arabic studies'],
      icon: '📖'
    },
    {
      title: 'Hadith Sciences',
      arabicTitle: 'علوم الحديث',
      description: 'In-depth study of prophetic traditions, their authentication, and practical application in daily life',
      features: ['Hadith collections study', 'Chain of narration analysis', 'Hadith authentication', 'Practical application'],
      icon: '📜'
    },
    {
      title: 'Islamic Jurisprudence (Fiqh)',
      arabicTitle: 'الفقه الإسلامي',
      description: 'Comprehensive study of Islamic law covering worship, transactions, family law, and contemporary issues',
      features: ['Classical Fiqh texts', 'Contemporary Islamic issues', 'Comparative jurisprudence', 'Fatwa methodology'],
      icon: '⚖️'
    },
    {
      title: 'Arabic Language',
      arabicTitle: 'اللغة العربية',
      description: 'Complete Arabic language program from beginner to advanced levels, including grammar, literature, and conversation',
      features: ['Arabic grammar (Nahw)', 'Arabic morphology (Sarf)', 'Classical literature', 'Modern Arabic conversation'],
      icon: '🔤'
    },
    {
      title: 'Islamic History',
      arabicTitle: 'التاريخ الإسلامي',
      description: 'Study of Islamic civilization, prophetic biography (Seerah), and the history of Islamic scholarship',
      features: ['Prophetic biography', 'Islamic civilization', 'Caliphate history', 'Contemporary Muslim world'],
      icon: '🏛️'
    },
    {
      title: 'Islamic Theology (Aqidah)',
      arabicTitle: 'العقيدة الإسلامية',
      description: 'Study of Islamic beliefs, creed, and theological principles according to authentic Islamic sources',
      features: ['Islamic creed', 'Comparative theology', 'Contemporary challenges', 'Spiritual development'],
      icon: '🌟'
    }
  ];

  const communityServices = [
    {
      title: 'Daily Prayers',
      description: 'Five daily congregational prayers led by qualified Imams',
      schedule: 'Fajr: 5:13 AM | Dhuhr: 12:47 PM | Asr: 4:15 PM | Maghrib: 7:04 PM | Isha: 8:15 PM',
      icon: '🕌'
    },
    {
      title: 'Friday Prayers (Jumu\'ah)',
      description: 'Weekly Friday congregational prayers with inspiring sermons',
      schedule: 'First Jumu\'ah: 1:00 PM | Second Jumu\'ah: 2:00 PM',
      icon: '📅'
    },
    {
      title: 'Islamic Counseling',
      description: 'Personal guidance and counseling services for spiritual and life matters',
      schedule: 'Available by appointment with our qualified counselors',
      icon: '🤝'
    },
    {
      title: 'Marriage Services',
      description: 'Islamic marriage ceremonies (Nikah) and pre-marital counseling',
      schedule: 'Ceremonies conducted according to Islamic traditions',
      icon: '💍'
    },
    {
      title: 'Funeral Services',
      description: 'Complete Islamic funeral services including Janazah prayers and burial',
      schedule: 'Available 24/7 for community members',
      icon: '🤲'
    },
    {
      title: 'Zakat Collection',
      description: 'Zakat collection and distribution to eligible recipients in the community',
      schedule: 'Year-round collection with transparent distribution',
      icon: '💰'
    }
  ];

  const specialPrograms = [
    {
      title: 'Ramadan Programs',
      description: 'Special Ramadan activities including Tarawih prayers, Iftar programs, and I\'tikaf',
      duration: 'Throughout the holy month of Ramadan',
      participants: 'Open to all community members'
    },
    {
      title: 'Youth Development',
      description: 'Islamic education and character development programs for young Muslims',
      duration: 'Year-round weekend programs',
      participants: 'Ages 13-25'
    },
    {
      title: 'Women\'s Circle',
      description: 'Islamic education and social programs specifically designed for women',
      duration: 'Weekly sessions every Saturday',
      participants: 'Women of all ages'
    },
    {
      title: 'Adult Education',
      description: 'Basic Islamic education and literacy programs for adults',
      duration: 'Evening classes Monday-Thursday',
      participants: 'Adults seeking Islamic knowledge'
    },
    {
      title: 'Children\'s Madrasa',
      description: 'Weekend Islamic school for children with age-appropriate curriculum',
      duration: 'Saturday and Sunday mornings',
      participants: 'Ages 5-12'
    },
    {
      title: 'Hajj & Umrah Guidance',
      description: 'Preparation courses and guidance for pilgrimage to Mecca',
      duration: 'Pre-Hajj season intensive courses',
      participants: 'Prospective pilgrims'
    }
  ];

  return (
    <div className="services-page">
      {/* Hero Section */}
      <section className="section" style={{ background: 'linear-gradient(135deg, #1e3a8a 0%, #3b82f6 100%)', color: 'white' }}>
        <div className="container">
          <div style={{ textAlign: 'center' }}>
            <div className="bismillah arabic-text" style={{ color: '#ffd700', fontSize: '2rem' }}>
              بِسْمِ اللَّهِ الرَّحْمَنِ الرَّحِيم
            </div>
            <h1 style={{ fontSize: '3rem', margin: '2rem 0', color: 'white' }}>Our Services</h1>
            <p style={{ fontSize: '1.3rem', maxWidth: '800px', margin: '0 auto' }}>
              Comprehensive Islamic education and community services serving the spiritual and educational needs of our community
            </p>
            <div className="arabic-text" style={{ color: '#ffd700', fontSize: '1.2rem', marginTop: '2rem' }}>
              خدماتنا التعليمية والمجتمعية
            </div>
            <p style={{ fontStyle: 'italic', marginTop: '1rem' }}>
              "And whoever saves a life, it is as if he has saved all of mankind" - Quran 5:32
            </p>
          </div>
        </div>
      </section>

      {/* Educational Services */}
      <section className="section">
        <div className="container">
          <h2 className="section-title">Educational Services</h2>
          <div className="grid grid-2">
            {educationalServices.map((service, index) => (
              <div key={index} className="card">
                <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', marginBottom: '1.5rem' }}>
                  <div style={{ fontSize: '3rem' }}>{service.icon}</div>
                  <div>
                    <h3 style={{ margin: 0, color: '#1e3a8a' }}>{service.title}</h3>
                    <div className="arabic-text" style={{ fontSize: '1rem', color: '#666' }}>
                      {service.arabicTitle}
                    </div>
                  </div>
                </div>
                
                <p style={{ marginBottom: '1.5rem' }}>{service.description}</p>
                
                <h4 style={{ color: '#1e3a8a', marginBottom: '1rem' }}>Program Features:</h4>
                <ul style={{ paddingLeft: '1.5rem' }}>
                  {service.features.map((feature, idx) => (
                    <li key={idx} style={{ marginBottom: '0.5rem' }}>{feature}</li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Community Services */}
      <section className="section" style={{ backgroundColor: '#f8fafc' }}>
        <div className="container">
          <h2 className="section-title">Community Services</h2>
          <div className="grid grid-2">
            {communityServices.map((service, index) => (
              <div key={index} className="card">
                <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', marginBottom: '1.5rem' }}>
                  <div style={{ fontSize: '3rem' }}>{service.icon}</div>
                  <h3 style={{ margin: 0, color: '#1e3a8a' }}>{service.title}</h3>
                </div>
                
                <p style={{ marginBottom: '1.5rem' }}>{service.description}</p>
                
                <div style={{ background: '#f1f5f9', padding: '1rem', borderRadius: '5px' }}>
                  <strong style={{ color: '#1e3a8a' }}>Schedule:</strong>
                  <p style={{ margin: '0.5rem 0 0 0', fontSize: '0.9rem' }}>{service.schedule}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Special Programs */}
      <section className="section">
        <div className="container">
          <h2 className="section-title">Special Programs</h2>
          <div className="grid grid-3">
            {specialPrograms.map((program, index) => (
              <div key={index} className="card">
                <h3 style={{ color: '#1e3a8a', marginBottom: '1rem' }}>{program.title}</h3>
                <p style={{ marginBottom: '1.5rem' }}>{program.description}</p>
                
                <div style={{ marginBottom: '1rem' }}>
                  <strong style={{ color: '#1e3a8a' }}>Duration:</strong>
                  <p style={{ margin: '0.5rem 0', fontSize: '0.9rem' }}>{program.duration}</p>
                </div>
                
                <div>
                  <strong style={{ color: '#1e3a8a' }}>Participants:</strong>
                  <p style={{ margin: '0.5rem 0', fontSize: '0.9rem' }}>{program.participants}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Admission Information */}
      <section className="section" style={{ backgroundColor: '#f8fafc' }}>
        <div className="container">
          <h2 className="section-title">Admission Information</h2>
          <div className="grid grid-2">
            <div className="card">
              <h3>How to Apply</h3>
              <ol style={{ paddingLeft: '1.5rem', marginBottom: '1.5rem' }}>
                <li style={{ marginBottom: '0.5rem' }}>Complete the application form</li>
                <li style={{ marginBottom: '0.5rem' }}>Submit required documents</li>
                <li style={{ marginBottom: '0.5rem' }}>Attend entrance interview</li>
                <li style={{ marginBottom: '0.5rem' }}>Take placement test (if applicable)</li>
                <li style={{ marginBottom: '0.5rem' }}>Receive admission decision</li>
              </ol>
              
              <h4 style={{ color: '#1e3a8a', marginBottom: '1rem' }}>Required Documents:</h4>
              <ul style={{ paddingLeft: '1.5rem' }}>
                <li>Completed application form</li>
                <li>Educational certificates</li>
                <li>Birth certificate or age declaration</li>
                <li>Passport photographs</li>
                <li>Medical certificate</li>
                <li>Character reference letters</li>
              </ul>
            </div>
            
            <div className="card">
              <h3>Academic Calendar</h3>
              <div style={{ marginBottom: '2rem' }}>
                <h4 style={{ color: '#1e3a8a', marginBottom: '1rem' }}>2025 Academic Year:</h4>
                <div style={{ marginBottom: '1rem' }}>
                  <strong>First Semester:</strong>
                  <p style={{ margin: '0.5rem 0', fontSize: '0.9rem' }}>September 15 - January 30</p>
                </div>
                <div style={{ marginBottom: '1rem' }}>
                  <strong>Second Semester:</strong>
                  <p style={{ margin: '0.5rem 0', fontSize: '0.9rem' }}>February 15 - June 30</p>
                </div>
                <div style={{ marginBottom: '1rem' }}>
                  <strong>Summer Programs:</strong>
                  <p style={{ margin: '0.5rem 0', fontSize: '0.9rem' }}>July 1 - August 31</p>
                </div>
              </div>
              
              <h4 style={{ color: '#1e3a8a', marginBottom: '1rem' }}>Application Deadlines:</h4>
              <ul style={{ paddingLeft: '1.5rem' }}>
                <li>Regular admission: August 31</li>
                <li>Late admission: September 10</li>
                <li>Transfer students: Rolling basis</li>
                <li>International students: July 31</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Fees and Scholarships */}
      <section className="section">
        <div className="container">
          <h2 className="section-title">Fees & Financial Aid</h2>
          <div className="grid grid-2">
            <div className="card">
              <h3>Tuition Fees (2025 Academic Year)</h3>
              <div style={{ marginBottom: '2rem' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '1rem', padding: '0.5rem', background: '#f8fafc', borderRadius: '5px' }}>
                  <span><strong>Full-time Islamic Studies</strong></span>
                  <span style={{ color: '#1e3a8a', fontWeight: 'bold' }}>₦150,000/year</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '1rem', padding: '0.5rem', background: '#f8fafc', borderRadius: '5px' }}>
                  <span><strong>Arabic Language Program</strong></span>
                  <span style={{ color: '#1e3a8a', fontWeight: 'bold' }}>₦120,000/year</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '1rem', padding: '0.5rem', background: '#f8fafc', borderRadius: '5px' }}>
                  <span><strong>Part-time Evening Classes</strong></span>
                  <span style={{ color: '#1e3a8a', fontWeight: 'bold' }}>₦80,000/year</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '1rem', padding: '0.5rem', background: '#f8fafc', borderRadius: '5px' }}>
                  <span><strong>Weekend Programs</strong></span>
                  <span style={{ color: '#1e3a8a', fontWeight: 'bold' }}>₦50,000/year</span>
                </div>
              </div>
              
              <p style={{ fontSize: '0.9rem', color: '#666' }}>
                * Fees include tuition, library access, and basic materials. 
                Accommodation and meals are additional.
              </p>
            </div>
            
            <div className="card">
              <h3>Scholarships & Financial Aid</h3>
              <div style={{ marginBottom: '2rem' }}>
                <h4 style={{ color: '#1e3a8a', marginBottom: '1rem' }}>Available Scholarships:</h4>
                <ul style={{ paddingLeft: '1.5rem', marginBottom: '1.5rem' }}>
                  <li><strong>Merit Scholarships:</strong> Up to 100% tuition coverage</li>
                  <li><strong>Need-based Aid:</strong> 25-75% tuition reduction</li>
                  <li><strong>Orphan Support:</strong> Full tuition and accommodation</li>
                  <li><strong>International Students:</strong> Partial scholarships available</li>
                  <li><strong>Alumni Children:</strong> 20% tuition discount</li>
                </ul>
                
                <h4 style={{ color: '#1e3a8a', marginBottom: '1rem' }}>Payment Options:</h4>
                <ul style={{ paddingLeft: '1.5rem' }}>
                  <li>Annual payment (5% discount)</li>
                  <li>Semester installments</li>
                  <li>Monthly payment plans</li>
                  <li>Work-study programs</li>
                </ul>
              </div>
              
              <button className="btn" style={{ width: '100%' }}>
                Apply for Financial Aid
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Contact for Services */}
      <section className="section" style={{ backgroundColor: '#f8fafc' }}>
        <div className="container">
          <div className="card" style={{ textAlign: 'center', background: 'linear-gradient(135deg, #1e3a8a 0%, #3b82f6 100%)', color: 'white' }}>
            <h2 style={{ color: 'white', marginBottom: '1rem' }}>Ready to Begin Your Islamic Education Journey?</h2>
            <p style={{ fontSize: '1.2rem', marginBottom: '2rem' }}>
              Join thousands of students who have benefited from our comprehensive Islamic education programs. 
              Contact us today to learn more about our services and admission process.
            </p>
            <div className="arabic-text" style={{ color: '#ffd700', fontSize: '1.5rem', marginBottom: '2rem' }}>
              وَقُل رَّبِّ زِدْنِي عِلْماً
            </div>
            <p style={{ fontStyle: 'italic', marginBottom: '2rem' }}>
              "And say: My Lord, increase me in knowledge" - Quran 20:114
            </p>
            <div style={{ display: 'flex', gap: '1rem', justifyContent: 'center', flexWrap: 'wrap' }}>
              <button className="btn btn-secondary">Apply Now</button>
              <button className="btn" style={{ background: 'rgba(255, 255, 255, 0.2)' }}>Download Brochure</button>
              <button className="btn" style={{ background: 'rgba(255, 255, 255, 0.2)' }}>Schedule Visit</button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Services;

