import React, { useState } from 'react';

const Contact = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    subject: '',
    message: ''
  });

  const handleInputChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Handle form submission
    console.log('Form submitted:', formData);
  };

  const contactInfo = [
    {
      icon: '📍',
      title: 'Address',
      details: ['1 Buyide Avenue', 'Alagbado, Lagos State', 'Nigeria'],
      arabicTitle: 'العنوان'
    },
    {
      icon: '📞',
      title: 'Phone Numbers',
      details: ['+234 803 123 4567', '+234 806 789 0123', '+234 701 234 5678'],
      arabicTitle: 'أرقام الهاتف'
    },
    {
      icon: '📧',
      title: 'Email Addresses',
      details: ['info@markazul-uloom.org', 'admissions@markazul-uloom.org', 'donations@markazul-uloom.org'],
      arabicTitle: 'البريد الإلكتروني'
    },
    {
      icon: '🌐',
      title: 'Website & Social Media',
      details: ['www.markazul-uloom.org', 'Facebook: @marcazululoomalagbado', 'WhatsApp: +234 803 123 4567'],
      arabicTitle: 'المواقع الاجتماعية'
    }
  ];

  const officeHours = [
    { day: 'Monday - Thursday', hours: '8:00 AM - 5:00 PM', arabic: 'الاثنين - الخميس' },
    { day: 'Friday', hours: '8:00 AM - 2:00 PM', arabic: 'الجمعة' },
    { day: 'Saturday', hours: '9:00 AM - 4:00 PM', arabic: 'السبت' },
    { day: 'Sunday', hours: '2:00 PM - 6:00 PM', arabic: 'الأحد' }
  ];

  const departments = [
    {
      name: 'Admissions Office',
      contact: 'admissions@markazul-uloom.org',
      phone: '+234 803 123 4567',
      head: 'Malam Yusuf Adebayo',
      services: ['Student applications', 'Academic inquiries', 'Scholarship information', 'Campus tours']
    },
    {
      name: 'Academic Affairs',
      contact: 'academic@markazul-uloom.org',
      phone: '+234 806 789 0123',
      head: 'Dr. Ibrahim Yusuf Al-Nigeriy',
      services: ['Curriculum information', 'Academic counseling', 'Transfer credits', 'Graduation requirements']
    },
    {
      name: 'Student Affairs',
      contact: 'students@markazul-uloom.org',
      phone: '+234 701 234 5678',
      head: 'Sister Khadijah Ogundimu',
      services: ['Student support', 'Accommodation', 'Counseling services', 'Student activities']
    },
    {
      name: 'Finance Office',
      contact: 'finance@markazul-uloom.org',
      phone: '+234 802 345 6789',
      head: 'Alhaji Abdullahi Musa',
      services: ['Fee payments', 'Financial aid', 'Scholarships', 'Payment plans']
    }
  ];

  return (
    <div className="contact-page">
      {/* Hero Section */}
      <section className="section" style={{ background: 'linear-gradient(135deg, #1e3a8a 0%, #3b82f6 100%)', color: 'white' }}>
        <div className="container">
          <div style={{ textAlign: 'center' }}>
            <div className="bismillah arabic-text" style={{ color: '#ffd700', fontSize: '2rem' }}>
              بِسْمِ اللَّهِ الرَّحْمَنِ الرَّحِيم
            </div>
            <h1 style={{ fontSize: '3rem', margin: '2rem 0', color: 'white' }}>Contact Us</h1>
            <p style={{ fontSize: '1.3rem', maxWidth: '800px', margin: '0 auto' }}>
              We're here to help and answer any questions you may have about our programs and services
            </p>
            <div className="arabic-text" style={{ color: '#ffd700', fontSize: '1.2rem', marginTop: '2rem' }}>
              اتصل بنا
            </div>
            <p style={{ fontStyle: 'italic', marginTop: '1rem' }}>
              "And whoever relies upon Allah - then He is sufficient for him" - Quran 65:3
            </p>
          </div>
        </div>
      </section>

      {/* Contact Information */}
      <section className="section">
        <div className="container">
          <h2 className="section-title">Get in Touch</h2>
          <div className="grid grid-2">
            {contactInfo.map((info, index) => (
              <div key={index} className="card">
                <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', marginBottom: '1.5rem' }}>
                  <div style={{ fontSize: '3rem' }}>{info.icon}</div>
                  <div>
                    <h3 style={{ margin: 0, color: '#1e3a8a' }}>{info.title}</h3>
                    <div className="arabic-text" style={{ fontSize: '1rem', color: '#666' }}>
                      {info.arabicTitle}
                    </div>
                  </div>
                </div>
                
                <div>
                  {info.details.map((detail, idx) => (
                    <p key={idx} style={{ margin: '0.5rem 0', fontSize: '1rem' }}>
                      {detail}
                    </p>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Form and Map */}
      <section className="section" style={{ backgroundColor: '#f8fafc' }}>
        <div className="container">
          <div className="grid grid-2">
            {/* Contact Form */}
            <div className="card">
              <h3 style={{ color: '#1e3a8a', marginBottom: '2rem' }}>Send us a Message</h3>
              <form onSubmit={handleSubmit}>
                <div style={{ marginBottom: '1.5rem' }}>
                  <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 'bold' }}>
                    Full Name *
                  </label>
                  <input
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleInputChange}
                    required
                    style={{
                      width: '100%',
                      padding: '0.8rem',
                      border: '1px solid #e2e8f0',
                      borderRadius: '5px',
                      fontSize: '1rem'
                    }}
                    placeholder="Enter your full name"
                  />
                </div>
                
                <div style={{ marginBottom: '1.5rem' }}>
                  <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 'bold' }}>
                    Email Address *
                  </label>
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    required
                    style={{
                      width: '100%',
                      padding: '0.8rem',
                      border: '1px solid #e2e8f0',
                      borderRadius: '5px',
                      fontSize: '1rem'
                    }}
                    placeholder="Enter your email address"
                  />
                </div>
                
                <div style={{ marginBottom: '1.5rem' }}>
                  <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 'bold' }}>
                    Phone Number
                  </label>
                  <input
                    type="tel"
                    name="phone"
                    value={formData.phone}
                    onChange={handleInputChange}
                    style={{
                      width: '100%',
                      padding: '0.8rem',
                      border: '1px solid #e2e8f0',
                      borderRadius: '5px',
                      fontSize: '1rem'
                    }}
                    placeholder="Enter your phone number"
                  />
                </div>
                
                <div style={{ marginBottom: '1.5rem' }}>
                  <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 'bold' }}>
                    Subject *
                  </label>
                  <select
                    name="subject"
                    value={formData.subject}
                    onChange={handleInputChange}
                    required
                    style={{
                      width: '100%',
                      padding: '0.8rem',
                      border: '1px solid #e2e8f0',
                      borderRadius: '5px',
                      fontSize: '1rem'
                    }}
                  >
                    <option value="">Select a subject</option>
                    <option value="admission">Admission Inquiry</option>
                    <option value="academic">Academic Information</option>
                    <option value="donation">Donation/Support</option>
                    <option value="general">General Inquiry</option>
                    <option value="complaint">Complaint/Feedback</option>
                    <option value="other">Other</option>
                  </select>
                </div>
                
                <div style={{ marginBottom: '2rem' }}>
                  <label style={{ display: 'block', marginBottom: '0.5rem', fontWeight: 'bold' }}>
                    Message *
                  </label>
                  <textarea
                    name="message"
                    value={formData.message}
                    onChange={handleInputChange}
                    required
                    rows="5"
                    style={{
                      width: '100%',
                      padding: '0.8rem',
                      border: '1px solid #e2e8f0',
                      borderRadius: '5px',
                      fontSize: '1rem',
                      resize: 'vertical'
                    }}
                    placeholder="Enter your message here..."
                  />
                </div>
                
                <button type="submit" className="btn" style={{ width: '100%', padding: '1rem' }}>
                  Send Message
                </button>
              </form>
            </div>
            
            {/* Map and Directions */}
            <div className="card">
              <h3 style={{ color: '#1e3a8a', marginBottom: '2rem' }}>Location & Directions</h3>
              
              {/* Placeholder for map */}
              <div style={{ 
                width: '100%', 
                height: '300px', 
                background: 'linear-gradient(135deg, #e2e8f0 0%, #f1f5f9 100%)',
                borderRadius: '10px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                marginBottom: '2rem',
                border: '2px dashed #1e3a8a'
              }}>
                <div style={{ textAlign: 'center', color: '#1e3a8a' }}>
                  <div style={{ fontSize: '3rem', marginBottom: '1rem' }}>🗺️</div>
                  <p><strong>Interactive Map</strong></p>
                  <p>1 Buyide Avenue, Alagbado, Lagos</p>
                </div>
              </div>
              
              <h4 style={{ color: '#1e3a8a', marginBottom: '1rem' }}>How to Find Us:</h4>
              <ul style={{ paddingLeft: '1.5rem', marginBottom: '2rem' }}>
                <li>From Lagos Island: Take the Lagos-Abeokuta Expressway</li>
                <li>From Ikeja: Head towards Agege, then Alagbado</li>
                <li>From Abule Egba: Take the main road towards Alagbado</li>
                <li>Look for the blue and white mosque with minarets</li>
                <li>Parking is available on the premises</li>
              </ul>
              
              <div style={{ background: '#f1f5f9', padding: '1rem', borderRadius: '5px' }}>
                <h4 style={{ color: '#1e3a8a', marginBottom: '0.5rem' }}>Public Transportation:</h4>
                <p style={{ fontSize: '0.9rem', margin: 0 }}>
                  Regular bus services available from major Lagos terminals. 
                  Alight at Alagbado Bus Stop and walk 5 minutes to Buyide Avenue.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Office Hours */}
      <section className="section">
        <div className="container">
          <h2 className="section-title">Office Hours</h2>
          <div className="card">
            <div className="grid grid-2">
              <div>
                <h3 style={{ color: '#1e3a8a', marginBottom: '2rem' }}>Administrative Office</h3>
                {officeHours.map((schedule, index) => (
                  <div key={index} style={{ 
                    display: 'flex', 
                    justifyContent: 'space-between', 
                    alignItems: 'center',
                    padding: '1rem',
                    marginBottom: '1rem',
                    background: '#f8fafc',
                    borderRadius: '5px'
                  }}>
                    <div>
                      <strong>{schedule.day}</strong>
                      <div className="arabic-text" style={{ fontSize: '0.9rem', color: '#666' }}>
                        {schedule.arabic}
                      </div>
                    </div>
                    <div style={{ color: '#1e3a8a', fontWeight: 'bold' }}>
                      {schedule.hours}
                    </div>
                  </div>
                ))}
              </div>
              
              <div>
                <h3 style={{ color: '#1e3a8a', marginBottom: '2rem' }}>Prayer Times</h3>
                <div style={{ background: '#f1f5f9', padding: '1.5rem', borderRadius: '10px' }}>
                  <p style={{ marginBottom: '1rem' }}>
                    <strong>Daily Prayers:</strong> Five times daily according to Islamic schedule
                  </p>
                  <p style={{ marginBottom: '1rem' }}>
                    <strong>Friday Prayers:</strong> 1:00 PM and 2:00 PM
                  </p>
                  <p style={{ marginBottom: '1rem' }}>
                    <strong>Ramadan Programs:</strong> Extended hours during holy month
                  </p>
                  <p style={{ margin: 0 }}>
                    <strong>Special Events:</strong> Check our announcements for Eid and other celebrations
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Department Contacts */}
      <section className="section" style={{ backgroundColor: '#f8fafc' }}>
        <div className="container">
          <h2 className="section-title">Department Contacts</h2>
          <div className="grid grid-2">
            {departments.map((dept, index) => (
              <div key={index} className="card">
                <h3 style={{ color: '#1e3a8a', marginBottom: '1rem' }}>{dept.name}</h3>
                
                <div style={{ marginBottom: '1.5rem' }}>
                  <p style={{ margin: '0.5rem 0' }}>
                    <strong>Head:</strong> {dept.head}
                  </p>
                  <p style={{ margin: '0.5rem 0' }}>
                    <strong>Email:</strong> {dept.contact}
                  </p>
                  <p style={{ margin: '0.5rem 0' }}>
                    <strong>Phone:</strong> {dept.phone}
                  </p>
                </div>
                
                <h4 style={{ color: '#1e3a8a', marginBottom: '1rem' }}>Services:</h4>
                <ul style={{ paddingLeft: '1.5rem' }}>
                  {dept.services.map((service, idx) => (
                    <li key={idx} style={{ marginBottom: '0.5rem' }}>{service}</li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Emergency Contact */}
      <section className="section">
        <div className="container">
          <div className="card" style={{ textAlign: 'center', background: 'linear-gradient(135deg, #1e3a8a 0%, #3b82f6 100%)', color: 'white' }}>
            <h2 style={{ color: 'white', marginBottom: '1rem' }}>Emergency Contact</h2>
            <p style={{ fontSize: '1.2rem', marginBottom: '2rem' }}>
              For urgent matters outside office hours, please contact our emergency line
            </p>
            
            <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', gap: '2rem', flexWrap: 'wrap', marginBottom: '2rem' }}>
              <div>
                <div style={{ fontSize: '2rem', marginBottom: '0.5rem' }}>📞</div>
                <strong>Emergency Hotline</strong>
                <p style={{ margin: '0.5rem 0', fontSize: '1.3rem', color: '#ffd700' }}>
                  +234 803 123 4567
                </p>
              </div>
              
              <div>
                <div style={{ fontSize: '2rem', marginBottom: '0.5rem' }}>💬</div>
                <strong>WhatsApp</strong>
                <p style={{ margin: '0.5rem 0', fontSize: '1.3rem', color: '#ffd700' }}>
                  +234 803 123 4567
                </p>
              </div>
            </div>
            
            <div className="arabic-text" style={{ color: '#ffd700', fontSize: '1.3rem', marginBottom: '1rem' }}>
              وَمَن يَتَّقِ اللَّهَ يَجْعَل لَّهُ مَخْرَجاً
            </div>
            <p style={{ fontStyle: 'italic' }}>
              "And whoever fears Allah - He will make for him a way out" - Quran 65:2
            </p>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Contact;

