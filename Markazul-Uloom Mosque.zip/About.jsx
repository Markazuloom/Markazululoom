import React from 'react';

const About = () => {
  return (
    <div className="about-page">
      {/* Hero Section */}
      <section className="section" style={{ background: 'linear-gradient(135deg, #1e3a8a 0%, #3b82f6 100%)', color: 'white' }}>
        <div className="container">
          <div style={{ textAlign: 'center' }}>
            <div className="bismillah arabic-text" style={{ color: '#ffd700', fontSize: '2rem' }}>
              بِسْمِ اللَّهِ الرَّحْمَنِ الرَّحِيم
            </div>
            <h1 style={{ fontSize: '3rem', margin: '2rem 0', color: 'white' }}>About Markazul-Uloom</h1>
            <p style={{ fontSize: '1.3rem', maxWidth: '800px', margin: '0 auto' }}>
              A beacon of Islamic education and spiritual guidance in Alagbado, Lagos, Nigeria
            </p>
            <div className="arabic-text" style={{ color: '#ffd700', fontSize: '1.2rem', marginTop: '2rem' }}>
              مركز العلوم للدراسات الإسلامية والعربية
            </div>
          </div>
        </div>
      </section>

      {/* Our Story */}
      <section className="section">
        <div className="container">
          <h2 className="section-title">Our Story</h2>
          <div className="grid grid-2">
            <div className="card">
              <h3>Foundation and Early Years</h3>
              <p>
                Markazul-Uloom was founded in 1985 with a simple yet profound vision: to provide 
                authentic Islamic education rooted in the Quran and Sunnah. What began as a small 
                study circle in Alagbado, Lagos, has grown into one of Nigeria's most respected 
                Islamic educational institutions.
              </p>
              <p>
                Our founders recognized the need for comprehensive Islamic education that would 
                prepare students not just for religious leadership, but for meaningful participation 
                in modern society while maintaining strong Islamic values.
              </p>
            </div>
            <div className="card">
              <h3>Growth and Development</h3>
              <p>
                Over four decades, Markazul-Uloom has evolved from a modest beginning to a 
                comprehensive Islamic institution offering various levels of Islamic and Arabic 
                studies. Our growth has been guided by the principle of quality over quantity, 
                ensuring that each graduate is well-prepared to serve their communities.
              </p>
              <p>
                Today, we serve over 500 students and have graduated more than 2,000 alumni who 
                are making positive contributions in various fields across Nigeria and beyond.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Mission, Vision, Values */}
      <section className="section" style={{ backgroundColor: '#f8fafc' }}>
        <div className="container">
          <h2 className="section-title">Our Mission, Vision & Values</h2>
          <div className="grid grid-3">
            <div className="card">
              <h3 style={{ color: '#1e3a8a', textAlign: 'center' }}>Mission</h3>
              <div className="arabic-text" style={{ fontSize: '1rem', marginBottom: '1rem' }}>
                رسالتنا
              </div>
              <p>
                To provide comprehensive Islamic education that combines traditional scholarship 
                with contemporary understanding, fostering spiritual growth, intellectual development, 
                and moral excellence in our students while serving the broader community through 
                various outreach programs.
              </p>
            </div>
            <div className="card">
              <h3 style={{ color: '#1e3a8a', textAlign: 'center' }}>Vision</h3>
              <div className="arabic-text" style={{ fontSize: '1rem', marginBottom: '1rem' }}>
                رؤيتنا
              </div>
              <p>
                To be a leading Islamic educational institution that produces knowledgeable, 
                righteous, and productive Muslims who contribute positively to society while 
                maintaining strong Islamic values and serving as ambassadors of Islam in their 
                various fields of endeavor.
              </p>
            </div>
            <div className="card">
              <h3 style={{ color: '#1e3a8a', textAlign: 'center' }}>Values</h3>
              <div className="arabic-text" style={{ fontSize: '1rem', marginBottom: '1rem' }}>
                قيمنا
              </div>
              <ul style={{ paddingLeft: '1.5rem' }}>
                <li>Authentic Islamic scholarship</li>
                <li>Excellence in education</li>
                <li>Community service</li>
                <li>Moral integrity</li>
                <li>Respect for diversity</li>
                <li>Continuous learning</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Academic Programs */}
      <section className="section">
        <div className="container">
          <h2 className="section-title">Academic Programs</h2>
          <div className="grid grid-2">
            <div className="card">
              <h3>Islamic Studies Curriculum</h3>
              <h4 style={{ color: '#1e3a8a', marginTop: '1.5rem' }}>Core Subjects:</h4>
              <ul style={{ paddingLeft: '1.5rem' }}>
                <li><strong>Quranic Studies:</strong> Memorization, recitation, and interpretation</li>
                <li><strong>Hadith Sciences:</strong> Study of prophetic traditions and methodology</li>
                <li><strong>Islamic Jurisprudence (Fiqh):</strong> Islamic law and legal principles</li>
                <li><strong>Islamic Theology (Aqidah):</strong> Beliefs and creed</li>
                <li><strong>Islamic History:</strong> Prophetic biography and Islamic civilization</li>
                <li><strong>Islamic Ethics (Akhlaq):</strong> Moral and spiritual development</li>
              </ul>
            </div>
            <div className="card">
              <h3>Arabic Language Program</h3>
              <h4 style={{ color: '#1e3a8a', marginTop: '1.5rem' }}>Language Skills:</h4>
              <ul style={{ paddingLeft: '1.5rem' }}>
                <li><strong>Arabic Grammar (Nahw):</strong> Syntax and sentence structure</li>
                <li><strong>Arabic Morphology (Sarf):</strong> Word formation and etymology</li>
                <li><strong>Arabic Literature:</strong> Classical and contemporary texts</li>
                <li><strong>Arabic Rhetoric (Balagha):</strong> Eloquence and literary analysis</li>
                <li><strong>Conversational Arabic:</strong> Speaking and communication skills</li>
                <li><strong>Arabic Calligraphy:</strong> Traditional Islamic art form</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Faculty and Leadership */}
      <section className="section" style={{ backgroundColor: '#f8fafc' }}>
        <div className="container">
          <h2 className="section-title">Faculty and Leadership</h2>
          <div className="card">
            <h3>Our Distinguished Faculty</h3>
            <p style={{ marginBottom: '2rem' }}>
              Markazul-Uloom is proud to have a team of highly qualified and experienced educators 
              who are committed to excellence in Islamic education. Our faculty members hold 
              advanced degrees from prestigious Islamic universities and bring decades of teaching 
              and research experience.
            </p>
            
            <div className="grid grid-2">
              <div>
                <h4 style={{ color: '#1e3a8a', marginBottom: '1rem' }}>Leadership Team</h4>
                <ul style={{ paddingLeft: '1.5rem' }}>
                  <li><strong>Sheikh Dr. Abass Abdul Azeez</strong> - Mudir (Director)</li>
                  <li><strong>Dr. Ibrahim Yusuf</strong> - Deputy Director, Academic Affairs</li>
                  <li><strong>Sheikh Ahmad Abdullahi</strong> - Head, Islamic Studies Department</li>
                  <li><strong>Dr. Fatima Al-Zahra</strong> - Head, Arabic Language Department</li>
                  <li><strong>Ustaz Muhammad Sani</strong> - Head, Quranic Studies</li>
                </ul>
              </div>
              <div>
                <h4 style={{ color: '#1e3a8a', marginBottom: '1rem' }}>Faculty Qualifications</h4>
                <ul style={{ paddingLeft: '1.5rem' }}>
                  <li>Ph.D. holders from Al-Azhar, Medina, and other renowned universities</li>
                  <li>Ijazah (certification) in Quranic recitation and memorization</li>
                  <li>Expertise in various schools of Islamic jurisprudence</li>
                  <li>Multilingual capabilities (Arabic, English, Hausa, Yoruba)</li>
                  <li>Active researchers and published scholars</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Facilities */}
      <section className="section">
        <div className="container">
          <h2 className="section-title">Our Facilities</h2>
          <div className="grid grid-3">
            <div className="card">
              <h3>Academic Facilities</h3>
              <ul style={{ paddingLeft: '1.5rem' }}>
                <li>Modern classrooms with audio-visual equipment</li>
                <li>Well-stocked Islamic library with rare manuscripts</li>
                <li>Computer laboratory with internet access</li>
                <li>Language laboratory for Arabic studies</li>
                <li>Research center for Islamic studies</li>
              </ul>
            </div>
            <div className="card">
              <h3>Worship Facilities</h3>
              <ul style={{ paddingLeft: '1.5rem' }}>
                <li>Main prayer hall accommodating 1000+ worshippers</li>
                <li>Separate prayer area for women</li>
                <li>Ablution facilities with modern amenities</li>
                <li>Mihrab with beautiful Islamic calligraphy</li>
                <li>Sound system for prayers and lectures</li>
              </ul>
            </div>
            <div className="card">
              <h3>Student Facilities</h3>
              <ul style={{ paddingLeft: '1.5rem' }}>
                <li>Dormitory accommodation for out-of-state students</li>
                <li>Cafeteria serving halal meals</li>
                <li>Recreation areas and sports facilities</li>
                <li>Medical clinic with qualified staff</li>
                <li>Transportation services</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Community Impact */}
      <section className="section" style={{ backgroundColor: '#f8fafc' }}>
        <div className="container">
          <h2 className="section-title">Community Impact</h2>
          <div className="grid grid-2">
            <div className="card">
              <h3>Educational Outreach</h3>
              <ul style={{ paddingLeft: '1.5rem' }}>
                <li>Adult literacy programs in Arabic and English</li>
                <li>Weekend Islamic classes for working professionals</li>
                <li>Children's Quranic memorization programs</li>
                <li>Women's Islamic education circles</li>
                <li>Youth development and mentorship programs</li>
                <li>Teacher training workshops for Islamic educators</li>
              </ul>
            </div>
            <div className="card">
              <h3>Social Services</h3>
              <ul style={{ paddingLeft: '1.5rem' }}>
                <li>Free medical clinics and health screenings</li>
                <li>Orphan care and support programs</li>
                <li>Widow assistance and empowerment initiatives</li>
                <li>Food distribution during Ramadan</li>
                <li>Scholarship programs for underprivileged students</li>
                <li>Conflict resolution and mediation services</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Alumni Success */}
      <section className="section">
        <div className="container">
          <h2 className="section-title">Alumni Success Stories</h2>
          <div className="card">
            <h3>Our Graduates Making a Difference</h3>
            <p style={{ marginBottom: '2rem' }}>
              Markazul-Uloom takes pride in its alumni who have gone on to serve in various 
              capacities across Nigeria and internationally. Our graduates are making significant 
              contributions in education, religious leadership, business, and public service.
            </p>
            
            <div className="grid grid-3">
              <div style={{ textAlign: 'center', padding: '1rem' }}>
                <div style={{ fontSize: '2.5rem', fontWeight: 'bold', color: '#1e3a8a' }}>150+</div>
                <h4>Imams and Religious Leaders</h4>
                <p>Leading congregations across Nigeria and West Africa</p>
              </div>
              <div style={{ textAlign: 'center', padding: '1rem' }}>
                <div style={{ fontSize: '2.5rem', fontWeight: 'bold', color: '#1e3a8a' }}>200+</div>
                <h4>Islamic Educators</h4>
                <p>Teaching in schools and universities</p>
              </div>
              <div style={{ textAlign: 'center', padding: '1rem' }}>
                <div style={{ fontSize: '2.5rem', fontWeight: 'bold', color: '#1e3a8a' }}>100+</div>
                <h4>Community Leaders</h4>
                <p>Serving in various leadership positions</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="section" style={{ backgroundColor: '#f8fafc' }}>
        <div className="container">
          <div className="card" style={{ textAlign: 'center', background: 'linear-gradient(135deg, #1e3a8a 0%, #3b82f6 100%)', color: 'white' }}>
            <h2 style={{ color: 'white', marginBottom: '1rem' }}>Join Our Community</h2>
            <p style={{ fontSize: '1.2rem', marginBottom: '2rem' }}>
              Whether you're seeking Islamic education, spiritual guidance, or community connection, 
              Markazul-Uloom welcomes you with open arms.
            </p>
            <div className="arabic-text" style={{ color: '#ffd700', fontSize: '1.5rem', marginBottom: '2rem' }}>
              وَقُل رَّبِّ زِدْنِي عِلْماً
            </div>
            <p style={{ fontStyle: 'italic', marginBottom: '2rem' }}>
              "And say: My Lord, increase me in knowledge" - Quran 20:114
            </p>
            <div style={{ display: 'flex', gap: '1rem', justifyContent: 'center', flexWrap: 'wrap' }}>
              <button className="btn btn-secondary">Apply for Admission</button>
              <button className="btn" style={{ background: 'rgba(255, 255, 255, 0.2)' }}>Visit Our Campus</button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;

