import React, { useState } from 'react';

const Donation = () => {
  const [selectedAmount, setSelectedAmount] = useState('');
  const [customAmount, setCustomAmount] = useState('');
  const [donationType, setDonationType] = useState('general');
  const [isRecurring, setIsRecurring] = useState(false);

  const predefinedAmounts = ['5000', '10000', '25000', '50000', '100000', '250000'];
  
  const donationCategories = [
    {
      id: 'general',
      title: 'General Support',
      arabicTitle: 'الدعم العام',
      description: 'Support our overall mission and daily operations',
      icon: '🏛️'
    },
    {
      id: 'education',
      title: 'Educational Programs',
      arabicTitle: 'البرامج التعليمية',
      description: 'Fund Islamic and Arabic education initiatives',
      icon: '📚'
    },
    {
      id: 'scholarship',
      title: 'Student Scholarships',
      arabicTitle: 'المنح الدراسية',
      description: 'Provide scholarships for underprivileged students',
      icon: '🎓'
    },
    {
      id: 'infrastructure',
      title: 'Infrastructure Development',
      arabicTitle: 'تطوير البنية التحتية',
      description: 'Improve and expand our facilities',
      icon: '🏗️'
    },
    {
      id: 'community',
      title: 'Community Outreach',
      arabicTitle: 'الخدمات المجتمعية',
      description: 'Support community welfare programs',
      icon: '🤝'
    },
    {
      id: 'library',
      title: 'Library & Resources',
      arabicTitle: 'المكتبة والموارد',
      description: 'Expand our Islamic library and digital resources',
      icon: '📖'
    }
  ];

  const impactStories = [
    {
      amount: '₦50,000',
      impact: 'Provides one student with a full year scholarship',
      description: 'Your donation can transform a young person\'s life through Islamic education'
    },
    {
      amount: '₦25,000',
      impact: 'Funds Arabic language classes for 10 students for one month',
      description: 'Help preserve and spread the Arabic language in our community'
    },
    {
      amount: '₦100,000',
      impact: 'Supports our community outreach programs for three months',
      description: 'Enables us to serve widows, orphans, and the underprivileged'
    },
    {
      amount: '₦10,000',
      impact: 'Provides Islamic books and materials for our library',
      description: 'Enhance our educational resources for current and future students'
    }
  ];

  return (
    <div className="donation-page">
      {/* Hero Section */}
      <section className="section" style={{ background: 'linear-gradient(135deg, #1e3a8a 0%, #3b82f6 100%)', color: 'white' }}>
        <div className="container">
          <div style={{ textAlign: 'center' }}>
            <div className="bismillah arabic-text" style={{ color: '#ffd700', fontSize: '2rem' }}>
              بِسْمِ اللَّهِ الرَّحْمَنِ الرَّحِيم
            </div>
            <h1 style={{ fontSize: '3rem', margin: '2rem 0', color: 'white' }}>Support Our Mission</h1>
            <p style={{ fontSize: '1.3rem', maxWidth: '800px', margin: '0 auto' }}>
              Your generous donation helps us continue providing quality Islamic education and serving our community
            </p>
            <div className="arabic-text" style={{ color: '#ffd700', fontSize: '1.2rem', marginTop: '2rem' }}>
              ادعموا رسالتنا التعليمية
            </div>
            <div style={{ marginTop: '2rem', padding: '2rem', background: 'rgba(255, 255, 255, 0.1)', borderRadius: '10px', display: 'inline-block' }}>
              <div className="arabic-text" style={{ color: '#ffd700', fontSize: '1.5rem', marginBottom: '1rem' }}>
                مَّن ذَا الَّذِي يُقْرِضُ اللَّهَ قَرْضًا حَسَنًا فَيُضَاعِفَهُ لَهُ أَضْعَافًا كَثِيرَةً
              </div>
              <p style={{ fontStyle: 'italic' }}>
                "Who is it that would loan Allah a goodly loan so He may multiply it for him many times over?" - Quran 2:245
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Donation Form */}
      <section className="section">
        <div className="container">
          <div className="grid grid-2">
            {/* Donation Categories */}
            <div>
              <h2 style={{ color: '#1e3a8a', marginBottom: '2rem' }}>Choose Your Cause</h2>
              <div className="grid grid-2" style={{ gap: '1rem' }}>
                {donationCategories.map((category) => (
                  <div 
                    key={category.id}
                    className={`card ${donationType === category.id ? 'selected' : ''}`}
                    style={{ 
                      cursor: 'pointer',
                      border: donationType === category.id ? '2px solid #1e3a8a' : '1px solid #e2e8f0',
                      background: donationType === category.id ? '#f8fafc' : 'white'
                    }}
                    onClick={() => setDonationType(category.id)}
                  >
                    <div style={{ fontSize: '2rem', marginBottom: '1rem' }}>{category.icon}</div>
                    <h3 style={{ fontSize: '1.1rem', marginBottom: '0.5rem' }}>{category.title}</h3>
                    <div className="arabic-text" style={{ fontSize: '0.9rem', marginBottom: '1rem', color: '#1e3a8a' }}>
                      {category.arabicTitle}
                    </div>
                    <p style={{ fontSize: '0.9rem', color: '#666' }}>{category.description}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Donation Amount */}
            <div className="card">
              <h2 style={{ color: '#1e3a8a', marginBottom: '2rem' }}>Donation Amount</h2>
              
              {/* Predefined Amounts */}
              <div style={{ marginBottom: '2rem' }}>
                <h3 style={{ fontSize: '1.1rem', marginBottom: '1rem' }}>Select Amount (₦)</h3>
                <div className="grid grid-3" style={{ gap: '0.5rem' }}>
                  {predefinedAmounts.map((amount) => (
                    <button
                      key={amount}
                      className={`btn ${selectedAmount === amount ? 'btn-secondary' : ''}`}
                      style={{ 
                        background: selectedAmount === amount ? '#1e3a8a' : 'white',
                        color: selectedAmount === amount ? 'white' : '#1e3a8a',
                        border: '1px solid #1e3a8a',
                        padding: '0.8rem'
                      }}
                      onClick={() => {
                        setSelectedAmount(amount);
                        setCustomAmount('');
                      }}
                    >
                      ₦{parseInt(amount).toLocaleString()}
                    </button>
                  ))}
                </div>
              </div>

              {/* Custom Amount */}
              <div style={{ marginBottom: '2rem' }}>
                <h3 style={{ fontSize: '1.1rem', marginBottom: '1rem' }}>Or Enter Custom Amount</h3>
                <div style={{ display: 'flex', alignItems: 'center' }}>
                  <span style={{ padding: '0.8rem', background: '#f1f5f9', border: '1px solid #e2e8f0', borderRight: 'none' }}>₦</span>
                  <input
                    type="number"
                    placeholder="Enter amount"
                    value={customAmount}
                    onChange={(e) => {
                      setCustomAmount(e.target.value);
                      setSelectedAmount('');
                    }}
                    style={{
                      flex: 1,
                      padding: '0.8rem',
                      border: '1px solid #e2e8f0',
                      borderLeft: 'none',
                      fontSize: '1rem'
                    }}
                  />
                </div>
              </div>

              {/* Recurring Donation */}
              <div style={{ marginBottom: '2rem' }}>
                <label style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', cursor: 'pointer' }}>
                  <input
                    type="checkbox"
                    checked={isRecurring}
                    onChange={(e) => setIsRecurring(e.target.checked)}
                    style={{ width: '1.2rem', height: '1.2rem' }}
                  />
                  <span>Make this a monthly recurring donation</span>
                </label>
                <p style={{ fontSize: '0.9rem', color: '#666', marginTop: '0.5rem' }}>
                  Recurring donations help us plan better and provide consistent support
                </p>
              </div>

              {/* Donation Summary */}
              <div style={{ background: '#f8fafc', padding: '1.5rem', borderRadius: '10px', marginBottom: '2rem' }}>
                <h3 style={{ color: '#1e3a8a', marginBottom: '1rem' }}>Donation Summary</h3>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.5rem' }}>
                  <span>Cause:</span>
                  <span style={{ fontWeight: 'bold' }}>
                    {donationCategories.find(cat => cat.id === donationType)?.title}
                  </span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.5rem' }}>
                  <span>Amount:</span>
                  <span style={{ fontWeight: 'bold', color: '#1e3a8a' }}>
                    ₦{(selectedAmount || customAmount || '0').toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')}
                  </span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                  <span>Frequency:</span>
                  <span style={{ fontWeight: 'bold' }}>{isRecurring ? 'Monthly' : 'One-time'}</span>
                </div>
              </div>

              {/* Donate Button */}
              <button 
                className="btn"
                style={{ width: '100%', padding: '1rem', fontSize: '1.1rem' }}
                disabled={!selectedAmount && !customAmount}
              >
                Donate Now - ₦{(selectedAmount || customAmount || '0').toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')}
              </button>

              <p style={{ fontSize: '0.8rem', color: '#666', textAlign: 'center', marginTop: '1rem' }}>
                Secure payment processing • Tax receipts available • 100% of your donation goes to the selected cause
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Impact Stories */}
      <section className="section" style={{ backgroundColor: '#f8fafc' }}>
        <div className="container">
          <h2 className="section-title">Your Impact</h2>
          <div className="grid grid-2">
            {impactStories.map((story, index) => (
              <div key={index} className="card">
                <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', marginBottom: '1rem' }}>
                  <div style={{ 
                    background: 'linear-gradient(135deg, #1e3a8a 0%, #3b82f6 100%)',
                    color: 'white',
                    padding: '1rem',
                    borderRadius: '10px',
                    fontWeight: 'bold',
                    fontSize: '1.1rem'
                  }}>
                    {story.amount}
                  </div>
                  <h3 style={{ margin: 0, color: '#1e3a8a' }}>{story.impact}</h3>
                </div>
                <p style={{ color: '#666' }}>{story.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Why Donate */}
      <section className="section">
        <div className="container">
          <h2 className="section-title">Why Your Support Matters</h2>
          <div className="grid grid-3">
            <div className="card" style={{ textAlign: 'center' }}>
              <div style={{ fontSize: '3rem', marginBottom: '1rem' }}>📈</div>
              <h3>Growing Impact</h3>
              <p>
                Over 40 years, we've educated thousands of students who now serve communities 
                across Nigeria and beyond. Your donation helps us expand this impact.
              </p>
            </div>
            <div className="card" style={{ textAlign: 'center' }}>
              <div style={{ fontSize: '3rem', marginBottom: '1rem' }}>🎯</div>
              <h3>Targeted Programs</h3>
              <p>
                Every donation is carefully allocated to specific programs, ensuring maximum 
                impact and transparency in how your contribution is used.
              </p>
            </div>
            <div className="card" style={{ textAlign: 'center' }}>
              <div style={{ fontSize: '3rem', marginBottom: '1rem' }}>🌍</div>
              <h3>Community Development</h3>
              <p>
                Beyond education, we support community welfare, healthcare initiatives, 
                and social programs that benefit the entire Alagbado community.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Other Ways to Give */}
      <section className="section" style={{ backgroundColor: '#f8fafc' }}>
        <div className="container">
          <h2 className="section-title">Other Ways to Support Us</h2>
          <div className="grid grid-2">
            <div className="card">
              <h3>Bank Transfer</h3>
              <p style={{ marginBottom: '1rem' }}>
                You can also make donations via direct bank transfer:
              </p>
              <div style={{ background: '#f1f5f9', padding: '1rem', borderRadius: '5px', fontFamily: 'monospace' }}>
                <strong>Account Name:</strong> Markazul-Uloom Islamic Institute<br/>
                <strong>Bank:</strong> First Bank of Nigeria<br/>
                <strong>Account Number:</strong> 2034567890<br/>
                <strong>Sort Code:</strong> 011-152-003
              </div>
              <p style={{ fontSize: '0.9rem', color: '#666', marginTop: '1rem' }}>
                Please send payment confirmation to donations@markazul-uloom.org
              </p>
            </div>
            
            <div className="card">
              <h3>Non-Monetary Contributions</h3>
              <ul style={{ paddingLeft: '1.5rem' }}>
                <li><strong>Books & Educational Materials:</strong> Islamic books, Arabic texts, educational resources</li>
                <li><strong>Equipment:</strong> Computers, projectors, furniture, vehicles</li>
                <li><strong>Professional Services:</strong> Legal, medical, accounting, construction</li>
                <li><strong>Volunteer Time:</strong> Teaching, administrative support, event organization</li>
                <li><strong>Waqf (Endowment):</strong> Land, buildings, or investment properties</li>
              </ul>
              <button className="btn btn-secondary" style={{ marginTop: '1rem' }}>
                Contact Us About In-Kind Donations
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Transparency & Accountability */}
      <section className="section">
        <div className="container">
          <div className="card" style={{ background: 'linear-gradient(135deg, #1e3a8a 0%, #3b82f6 100%)', color: 'white' }}>
            <h2 style={{ color: 'white', textAlign: 'center', marginBottom: '2rem' }}>
              Transparency & Accountability
            </h2>
            <div className="grid grid-3">
              <div style={{ textAlign: 'center' }}>
                <div style={{ fontSize: '2.5rem', marginBottom: '1rem' }}>📊</div>
                <h3 style={{ color: 'white' }}>Annual Reports</h3>
                <p>Detailed financial reports published annually showing how donations are used</p>
              </div>
              <div style={{ textAlign: 'center' }}>
                <div style={{ fontSize: '2.5rem', marginBottom: '1rem' }}>✅</div>
                <h3 style={{ color: 'white' }}>Certified Audits</h3>
                <p>Independent audits ensure proper financial management and accountability</p>
              </div>
              <div style={{ textAlign: 'center' }}>
                <div style={{ fontSize: '2.5rem', marginBottom: '1rem' }}>📧</div>
                <h3 style={{ color: 'white' }}>Regular Updates</h3>
                <p>Donors receive regular updates on projects and impact of their contributions</p>
              </div>
            </div>
            
            <div style={{ textAlign: 'center', marginTop: '2rem' }}>
              <div className="arabic-text" style={{ color: '#ffd700', fontSize: '1.3rem', marginBottom: '1rem' }}>
                إِنَّ اللَّهَ يَأْمُرُ بِالْعَدْلِ وَالْإِحْسَانِ
              </div>
              <p style={{ fontStyle: 'italic' }}>
                "Indeed, Allah orders justice and good conduct" - Quran 16:90
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Contact for Donations */}
      <section className="section" style={{ backgroundColor: '#f8fafc' }}>
        <div className="container">
          <div className="card" style={{ textAlign: 'center' }}>
            <h2 style={{ color: '#1e3a8a', marginBottom: '1rem' }}>Questions About Donating?</h2>
            <p style={{ fontSize: '1.1rem', marginBottom: '2rem', maxWidth: '600px', margin: '0 auto 2rem' }}>
              Our team is here to help you make the most impactful donation possible. 
              Contact us for personalized assistance or to discuss larger contributions.
            </p>
            
            <div className="grid grid-3" style={{ marginBottom: '2rem' }}>
              <div>
                <strong>📞 Phone</strong>
                <p>+234 803 123 4567</p>
              </div>
              <div>
                <strong>📧 Email</strong>
                <p>donations@markazul-uloom.org</p>
              </div>
              <div>
                <strong>📍 Visit Us</strong>
                <p>1 Buyide Avenue, Alagbado, Lagos</p>
              </div>
            </div>
            
            <div style={{ display: 'flex', gap: '1rem', justifyContent: 'center', flexWrap: 'wrap' }}>
              <button className="btn">Schedule a Meeting</button>
              <button className="btn btn-secondary">Download Donation Guide</button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Donation;

