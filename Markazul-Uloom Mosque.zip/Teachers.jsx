import React from 'react';

const Teachers = () => {
  const seniorFaculty = [
    {
      name: 'Sheikh Dr. Abass Abdul Azeez',
      title: 'Mudir (Director)',
      arabicName: 'الشيخ الدكتور عباس عبد العزيز',
      specialization: 'Islamic Studies, Tafsir, Hadith Sciences',
      education: 'Ph.D. Islamic Studies, Al-Azhar University',
      experience: '25+ years',
      description: 'Leading Islamic scholar with extensive experience in Quranic interpretation and Islamic jurisprudence. Regular speaker at international Islamic conferences.'
    },
    {
      name: 'Dr. Ibrahim Yusuf Al-Nigeriy',
      title: 'Deputy Director, Academic Affairs',
      arabicName: 'الدكتور إبراهيم يوسف النيجيري',
      specialization: 'Islamic Jurisprudence, Comparative Fiqh',
      education: 'Ph.D. Islamic Law, Islamic University of Medina',
      experience: '20+ years',
      description: 'Expert in comparative Islamic jurisprudence with deep knowledge of various schools of Islamic law. Author of several academic papers on contemporary Islamic issues.'
    },
    {
      name: 'Sheikh Ahmad Abdullahi',
      title: 'Head, Islamic Studies Department',
      arabicName: 'الشيخ أحمد عبد الله',
      specialization: 'Hadith Sciences, Islamic History',
      education: 'M.A. Hadith Studies, Umm Al-Qura University',
      experience: '18+ years',
      description: 'Renowned hadith scholar with ijazah in multiple hadith collections. Specializes in hadith authentication and prophetic biography.'
    },
    {
      name: 'Dr. Fatima Al-Zahra Bint Ahmad',
      title: 'Head, Arabic Language Department',
      arabicName: 'الدكتورة فاطمة الزهراء بنت أحمد',
      specialization: 'Arabic Grammar, Literature, Rhetoric',
      education: 'Ph.D. Arabic Literature, Cairo University',
      experience: '15+ years',
      description: 'Distinguished Arabic language expert with specialization in classical Arabic literature and modern linguistic methodologies.'
    }
  ];

  const arabicFaculty = [
    {
      name: 'Ustaz Muhammad Sani',
      title: 'Head, Quranic Studies',
      arabicName: 'الأستاذ محمد ثاني',
      specialization: 'Quranic Recitation, Memorization',
      education: 'Ijazah in 10 Qira\'at, Madinah',
      experience: '22+ years'
    },
    {
      name: 'Sheikh Umar Farouk',
      title: 'Senior Arabic Instructor',
      arabicName: 'الشيخ عمر فاروق',
      specialization: 'Arabic Grammar, Morphology',
      education: 'M.A. Arabic Language, Al-Azhar',
      experience: '16+ years'
    },
    {
      name: 'Dr. Aisha Abdurrahman',
      title: 'Women\'s Islamic Education Coordinator',
      arabicName: 'الدكتورة عائشة عبد الرحمن',
      specialization: 'Islamic Ethics, Women\'s Studies',
      education: 'Ph.D. Islamic Studies, IIUM Malaysia',
      experience: '12+ years'
    },
    {
      name: 'Ustaz Bilal Ibn Mas\'ud',
      title: 'Hadith and Seerah Instructor',
      arabicName: 'الأستاذ بلال بن مسعود',
      specialization: 'Prophetic Biography, Islamic History',
      education: 'M.A. Islamic History, Medina',
      experience: '14+ years'
    }
  ];

  const supportStaff = [
    {
      name: 'Malam Yusuf Adebayo',
      title: 'Librarian',
      specialization: 'Islamic Manuscripts, Digital Archives',
      experience: '10+ years'
    },
    {
      name: 'Sister Khadijah Ogundimu',
      title: 'Student Affairs Coordinator',
      specialization: 'Student Counseling, Academic Support',
      experience: '8+ years'
    },
    {
      name: 'Ustaz Abdullahi Musa',
      title: 'IT Coordinator',
      specialization: 'Educational Technology, Online Learning',
      experience: '6+ years'
    },
    {
      name: 'Dr. Amina Hassan',
      title: 'Research Coordinator',
      specialization: 'Islamic Research, Academic Publications',
      experience: '9+ years'
    }
  ];

  return (
    <div className="teachers-page">
      {/* Hero Section */}
      <section className="section" style={{ background: 'linear-gradient(135deg, #1e3a8a 0%, #3b82f6 100%)', color: 'white' }}>
        <div className="container">
          <div style={{ textAlign: 'center' }}>
            <div className="bismillah arabic-text" style={{ color: '#ffd700', fontSize: '2rem' }}>
              بِسْمِ اللَّهِ الرَّحْمَنِ الرَّحِيم
            </div>
            <h1 style={{ fontSize: '3rem', margin: '2rem 0', color: 'white' }}>Our Distinguished Faculty</h1>
            <p style={{ fontSize: '1.3rem', maxWidth: '800px', margin: '0 auto' }}>
              Meet the dedicated scholars and educators who guide our students on their journey of Islamic learning
            </p>
            <div className="arabic-text" style={{ color: '#ffd700', fontSize: '1.2rem', marginTop: '2rem' }}>
              هيئة التدريس المتميزة
            </div>
            <p style={{ fontStyle: 'italic', marginTop: '1rem' }}>
              "And it is not for the believers to go forth all at once. For there should separate from every division of them a group remaining to obtain understanding in the religion" - Quran 9:122
            </p>
          </div>
        </div>
      </section>

      {/* Senior Faculty */}
      <section className="section">
        <div className="container">
          <h2 className="section-title">Senior Faculty & Leadership</h2>
          <div className="grid grid-2">
            {seniorFaculty.map((faculty, index) => (
              <div key={index} className="card">
                <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', marginBottom: '1.5rem' }}>
                  <div style={{ 
                    width: '80px', 
                    height: '80px', 
                    borderRadius: '50%', 
                    background: 'linear-gradient(135deg, #1e3a8a 0%, #3b82f6 100%)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    color: 'white',
                    fontSize: '1.5rem',
                    fontWeight: 'bold',
                    flexShrink: 0
                  }}>
                    {faculty.name.split(' ')[0].charAt(0)}{faculty.name.split(' ')[1]?.charAt(0)}
                  </div>
                  <div>
                    <h3 style={{ margin: '0 0 0.5rem 0', color: '#1e3a8a' }}>{faculty.name}</h3>
                    <p style={{ margin: '0', fontWeight: 'bold', color: '#666' }}>{faculty.title}</p>
                  </div>
                </div>
                
                <div className="arabic-text" style={{ fontSize: '1rem', marginBottom: '1rem', color: '#1e3a8a' }}>
                  {faculty.arabicName}
                </div>
                
                <div style={{ marginBottom: '1rem' }}>
                  <strong style={{ color: '#1e3a8a' }}>Specialization:</strong>
                  <p style={{ margin: '0.5rem 0' }}>{faculty.specialization}</p>
                </div>
                
                <div style={{ marginBottom: '1rem' }}>
                  <strong style={{ color: '#1e3a8a' }}>Education:</strong>
                  <p style={{ margin: '0.5rem 0' }}>{faculty.education}</p>
                </div>
                
                <div style={{ marginBottom: '1rem' }}>
                  <strong style={{ color: '#1e3a8a' }}>Experience:</strong>
                  <p style={{ margin: '0.5rem 0' }}>{faculty.experience}</p>
                </div>
                
                <p style={{ fontSize: '0.95rem', lineHeight: '1.6' }}>{faculty.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Arabic & Islamic Studies Faculty */}
      <section className="section" style={{ backgroundColor: '#f8fafc' }}>
        <div className="container">
          <h2 className="section-title">Arabic & Islamic Studies Faculty</h2>
          <div className="grid grid-2">
            {arabicFaculty.map((faculty, index) => (
              <div key={index} className="card">
                <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', marginBottom: '1.5rem' }}>
                  <div style={{ 
                    width: '70px', 
                    height: '70px', 
                    borderRadius: '50%', 
                    background: 'linear-gradient(135deg, #059669 0%, #10b981 100%)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    color: 'white',
                    fontSize: '1.3rem',
                    fontWeight: 'bold',
                    flexShrink: 0
                  }}>
                    {faculty.name.split(' ')[0].charAt(0)}{faculty.name.split(' ')[1]?.charAt(0)}
                  </div>
                  <div>
                    <h3 style={{ margin: '0 0 0.5rem 0', color: '#1e3a8a' }}>{faculty.name}</h3>
                    <p style={{ margin: '0', fontWeight: 'bold', color: '#666' }}>{faculty.title}</p>
                  </div>
                </div>
                
                <div className="arabic-text" style={{ fontSize: '1rem', marginBottom: '1rem', color: '#1e3a8a' }}>
                  {faculty.arabicName}
                </div>
                
                <div style={{ marginBottom: '1rem' }}>
                  <strong style={{ color: '#1e3a8a' }}>Specialization:</strong>
                  <p style={{ margin: '0.5rem 0' }}>{faculty.specialization}</p>
                </div>
                
                <div style={{ marginBottom: '1rem' }}>
                  <strong style={{ color: '#1e3a8a' }}>Education:</strong>
                  <p style={{ margin: '0.5rem 0' }}>{faculty.education}</p>
                </div>
                
                <div>
                  <strong style={{ color: '#1e3a8a' }}>Experience:</strong>
                  <p style={{ margin: '0.5rem 0' }}>{faculty.experience}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Support Staff */}
      <section className="section">
        <div className="container">
          <h2 className="section-title">Support Staff & Administration</h2>
          <div className="grid grid-2">
            {supportStaff.map((staff, index) => (
              <div key={index} className="card">
                <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', marginBottom: '1rem' }}>
                  <div style={{ 
                    width: '60px', 
                    height: '60px', 
                    borderRadius: '50%', 
                    background: 'linear-gradient(135deg, #7c3aed 0%, #a855f7 100%)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    color: 'white',
                    fontSize: '1.2rem',
                    fontWeight: 'bold',
                    flexShrink: 0
                  }}>
                    {staff.name.split(' ')[0].charAt(0)}{staff.name.split(' ')[1]?.charAt(0)}
                  </div>
                  <div>
                    <h3 style={{ margin: '0 0 0.5rem 0', color: '#1e3a8a' }}>{staff.name}</h3>
                    <p style={{ margin: '0', fontWeight: 'bold', color: '#666' }}>{staff.title}</p>
                  </div>
                </div>
                
                <div style={{ marginBottom: '1rem' }}>
                  <strong style={{ color: '#1e3a8a' }}>Specialization:</strong>
                  <p style={{ margin: '0.5rem 0' }}>{staff.specialization}</p>
                </div>
                
                <div>
                  <strong style={{ color: '#1e3a8a' }}>Experience:</strong>
                  <p style={{ margin: '0.5rem 0' }}>{staff.experience}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Faculty Achievements */}
      <section className="section" style={{ backgroundColor: '#f8fafc' }}>
        <div className="container">
          <h2 className="section-title">Faculty Achievements & Recognition</h2>
          <div className="grid grid-3">
            <div className="card">
              <h3>Academic Publications</h3>
              <div style={{ fontSize: '2.5rem', fontWeight: 'bold', color: '#1e3a8a', textAlign: 'center', marginBottom: '1rem' }}>
                50+
              </div>
              <p style={{ textAlign: 'center' }}>
                Research papers, books, and articles published by our faculty in various Islamic studies journals and conferences.
              </p>
            </div>
            <div className="card">
              <h3>International Recognition</h3>
              <div style={{ fontSize: '2.5rem', fontWeight: 'bold', color: '#1e3a8a', textAlign: 'center', marginBottom: '1rem' }}>
                15+
              </div>
              <p style={{ textAlign: 'center' }}>
                Faculty members invited as keynote speakers at international Islamic conferences and symposiums.
              </p>
            </div>
            <div className="card">
              <h3>Advanced Degrees</h3>
              <div style={{ fontSize: '2.5rem', fontWeight: 'bold', color: '#1e3a8a', textAlign: 'center', marginBottom: '1rem' }}>
                85%
              </div>
              <p style={{ textAlign: 'center' }}>
                Of our faculty hold advanced degrees (Masters or Ph.D.) from renowned Islamic universities worldwide.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Teaching Philosophy */}
      <section className="section">
        <div className="container">
          <h2 className="section-title">Our Teaching Philosophy</h2>
          <div className="card" style={{ background: 'linear-gradient(135deg, #1e3a8a 0%, #3b82f6 100%)', color: 'white' }}>
            <div className="grid grid-2">
              <div>
                <h3 style={{ color: 'white', marginBottom: '1.5rem' }}>Traditional Scholarship</h3>
                <p style={{ marginBottom: '1rem' }}>
                  Our faculty maintains the authentic chain of Islamic scholarship (Isnad) while employing 
                  traditional teaching methodologies that have preserved Islamic knowledge for centuries.
                </p>
                <ul style={{ paddingLeft: '1.5rem' }}>
                  <li>Ijazah-based certification system</li>
                  <li>Memorization and understanding balance</li>
                  <li>Classical Arabic text studies</li>
                  <li>Scholarly debate and discussion</li>
                </ul>
              </div>
              <div>
                <h3 style={{ color: 'white', marginBottom: '1.5rem' }}>Modern Pedagogy</h3>
                <p style={{ marginBottom: '1rem' }}>
                  We integrate contemporary educational methods and technology to make Islamic learning 
                  accessible and relevant to modern students while maintaining authenticity.
                </p>
                <ul style={{ paddingLeft: '1.5rem' }}>
                  <li>Interactive learning techniques</li>
                  <li>Digital resources and tools</li>
                  <li>Practical application focus</li>
                  <li>Critical thinking development</li>
                </ul>
              </div>
            </div>
            
            <div style={{ textAlign: 'center', marginTop: '2rem', padding: '2rem', background: 'rgba(255, 255, 255, 0.1)', borderRadius: '10px' }}>
              <div className="arabic-text" style={{ color: '#ffd700', fontSize: '1.5rem', marginBottom: '1rem' }}>
                إِنَّمَا يَخْشَى اللَّهَ مِنْ عِبَادِهِ الْعُلَمَاءُ
              </div>
              <p style={{ fontStyle: 'italic' }}>
                "Only those fear Allah, from among His servants, who have knowledge" - Quran 35:28
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Join Our Faculty */}
      <section className="section" style={{ backgroundColor: '#f8fafc' }}>
        <div className="container">
          <div className="card" style={{ textAlign: 'center' }}>
            <h2 style={{ color: '#1e3a8a', marginBottom: '1rem' }}>Join Our Faculty</h2>
            <p style={{ fontSize: '1.2rem', marginBottom: '2rem', maxWidth: '600px', margin: '0 auto 2rem' }}>
              Are you a qualified Islamic scholar or Arabic language expert? We welcome applications 
              from dedicated educators who share our commitment to authentic Islamic education.
            </p>
            
            <div style={{ marginBottom: '2rem' }}>
              <h3 style={{ color: '#1e3a8a', marginBottom: '1rem' }}>We Seek Candidates With:</h3>
              <div className="grid grid-2" style={{ textAlign: 'left' }}>
                <ul style={{ paddingLeft: '1.5rem' }}>
                  <li>Advanced degrees in Islamic Studies or Arabic</li>
                  <li>Proven teaching experience</li>
                  <li>Strong command of Arabic and English</li>
                  <li>Commitment to Islamic values and ethics</li>
                </ul>
                <ul style={{ paddingLeft: '1.5rem' }}>
                  <li>Research and publication experience</li>
                  <li>Ability to work in a multicultural environment</li>
                  <li>Passion for Islamic education</li>
                  <li>Excellent communication skills</li>
                </ul>
              </div>
            </div>
            
            <div style={{ display: 'flex', gap: '1rem', justifyContent: 'center', flexWrap: 'wrap' }}>
              <button className="btn">Submit Application</button>
              <button className="btn btn-secondary">Faculty Handbook</button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Teachers;

